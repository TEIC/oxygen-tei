/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.access;

import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * Provides methods for table actions and informations regarding the table content.  
 */
public interface AuthorTableAccess {
  
  /**
   * Find the cell included into the previous row and has the same column index
   * as the specified cell {@link AuthorElement}.
   * 
   * @param cellElement The table cell element.
   * @return The cell above the given one. 
   * Can be <code>null</code> if there is no cell above the given one
   * or the element does not correspond to a table cell..
   */
  AuthorElement getTableCellAbove(AuthorElement cellElement);
  
  /**
   * Find the cell included into the next row and has the same column index
   * as the specified cell {@link AuthorElement}.
   * 
   * @param cellElement The table cell element.
   * @return The cell bellow the given one. 
   * Can be <code>null</code> if there is no cell bellow the given one
   * or the element does not correspond to a table cell..
   */
  AuthorElement getTableCellBelow(AuthorElement cellElement);
  
  /**
   * Obtain the table row and column index for the cell corresponding to the 
   * specified cell {@link AuthorElement}.
   * 
   * @param cellElement The table cell element.
   * @return an array containing the row index on the first position and column 
   * index on second one. Both are 0 based.
   * Can be <code>null</code> if the element does not correspond to a cell in a table.
   */
  int[] getTableCellIndex(AuthorElement cellElement);
  
  /**
   * Obtain the cell {@link AuthorElement} for the given row and column in the 
   * specified table.
   * 
   * @param row          The row, 0 based.
   * @param column       The column, 0 based.
   * @param tableElement The table element.
   * @return             The element at the specified location. 
   * Can be <code>null</code> if the table does not have a cell at the provided indices.
   */
  AuthorElement getTableCellAt(int row, int column, AuthorElement tableElement);

  /**
   * Find the table row element for the given index.
   * 
   * @param index        The index of the row to find the element for, 0 based.
   * @param tableElement The table element.
   * @return             The table row. 
   * Can be <code>null</code> if the table does not have a row at the given index.
   */
  AuthorElement getTableRow(int index, AuthorElement tableElement);
  
  /**
   * Get the row count for the given table {@link AuthorElement}. 
   * 
   * @param tableElement The table element.
   * @return             The row count.
   */
  int getTableRowCount(AuthorElement tableElement);

  /**
   * Returns the number of columns for the given table {@link AuthorElement}.
   * 
   * @param tableElement The table element.
   * @return             The number of columns.
   */
  int getTableNumberOfColumns(AuthorElement tableElement);

  /**
   * For the given cell {@link AuthorElement} find the start and end column 
   * defining the column span interval. 
   * The indices are 0 based.
   * 
   * @param cellElement The table cell element.
   * @return An array containing the start span column index on the first position and 
   * the end span column index on the second one. 
   * Can be <code>null</code> if the element does not correspond to a cell in a table.
   */
  int[] getTableColSpanIndices(AuthorElement cellElement);
  
  /**
   * For the given cell {@link AuthorElement} find the start and end row 
   * defining the row span interval. 
   * The indices are 0 based.
   * 
   * @param cellElement The table cell element.
   * @return An array containing the start span row index on the first position and 
   * the end span row index on the second one. 
   * Can be <code>null</code> if the element does not correspond to a cell in a table.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  int[] getTableRowSpanIndices(AuthorElement cellElement);
}