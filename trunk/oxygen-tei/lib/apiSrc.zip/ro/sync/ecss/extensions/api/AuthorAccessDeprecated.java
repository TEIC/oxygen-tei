/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.io.File;
import java.net.URL;

import javax.swing.text.BadLocationException;

import org.xml.sax.XMLReader;

import ro.sync.ecss.extensions.api.access.AuthorEditorAccess;
import ro.sync.ecss.extensions.api.access.AuthorTableAccess;
import ro.sync.ecss.extensions.api.access.AuthorUtilAccess;
import ro.sync.ecss.extensions.api.access.AuthorWorkspaceAccess;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Contains methods that are deprecated in the {@link AuthorAccess} 
 * and should no longer be used. 
 */
public interface AuthorAccessDeprecated {
  /**
   * Get the offset of the selection start. It is inclusive.
   * 
   * @return The offset of the selection start, 0 based.
   * @deprecated Use <code>{@link AuthorEditorAccess#getSelectionStart()}</code> instead.
   */
  @Deprecated
  int getSelectionStart();
  
  /**
   * Get the offset of the selection end. It is exclusive.
   * 
   * @return The offset of the selection end, zero based.
   * @deprecated Use <code>{@link AuthorEditorAccess#getSelectionEnd()}</code> instead.
   */
  @Deprecated
  int getSelectionEnd();
  
  /**
   * Get the selected text. The text does not contains XML tags. 
   * 
   * @return The selected text or the empty string if no selection is present.
   * @deprecated Use <code>{@link AuthorEditorAccess#getSelectedText()}</code> instead.
   */
  @Deprecated
  String getSelectedText();
  
  /**
   * The current caret offset.
   * 
   * @return The caret offset, 0 based.
   * @deprecated Use <code>{@link AuthorEditorAccess#getCaretOffset()}</code> instead. For example if you 
   * have an AuthorAccess object then use authorAccess.getEditorAccess().getCaretOffset().
   */
  @Deprecated
  int getCaretOffset();
  
  /**
   * Inserts a text at the offset. After the operation is performed the caret will be positioned at the end 
   * of the inserted text.
   * 
   * @param text The text to insert.
   * @param offset The offset of the insertion point, 0 based.
   * @deprecated Use {@link AuthorDocumentController#insertText(int, String)} instead.
   */
  @Deprecated
  void insertText(String text, int offset);
  
  /**
   * Insert an XML fragment at the given offset. 
   * After the operation is performed the caret will be positioned at the end of the inserted XML fragment.
   * 
   * @param xmlFragment The XML fragment.
   * @param offset The offset of the insertion point, 0 based.
   * @throws AuthorOperationException If it could not be inserted.
   * @deprecated Use {@link AuthorDocumentController#insertXMLFragment(String, int)} instead.
   */
  @Deprecated
  void insertXMLFragment(String xmlFragment, int offset) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment at the node specified by the xpathLocation and relativePosition.
   * Note: if the <code>xpathLocation</code> is not specified then the XML fragment 
   * will be inserted at the caret position(<code>relativePosition<code> is ignored). <p>
   * After the operation is performed the caret will be positioned at the end of the inserted XML fragment. 
   * 
   * @param xmlFragment The XML fragment.
   * @param xpathLocation The xpath location.
   * @param relativePosition The position relative to the node identified by the xpath location. 
   * Can be one of the constants: AuthorConstants.POSITION_BEFORE, AuthorConstants.POSITION_AFTER,
   * AuthorConstants.POSITION_INSIDE.
   * @throws AuthorOperationException If it could not be inserted.
   * @deprecated Use {@link AuthorDocumentController#insertXMLFragment(String, String, String)} instead.
   */
  @Deprecated
  void insertXMLFragment(String xmlFragment, String xpathLocation, String relativePosition) throws AuthorOperationException;
  
  /**
   * Delete the selected text, if any.
   * @deprecated Use {@link AuthorEditorAccess#deleteSelection()} instead.
   */
  @Deprecated
  void deleteSelection();
  
  /**
   * @return <code>true</code> If there is a selection, <code>false</code> otherwise.
   * @deprecated Use {@link AuthorEditorAccess#hasSelection()} instead.
   */
  @Deprecated
  boolean hasSelection();
  
  /**
   * Select the word at caret.
   * @deprecated Use {@link AuthorEditorAccess#selectWord()} instead.
   */
  @Deprecated
  void selectWord();
  
  /**
   * Surround the given offsets in <code>xmlFragment</code>. 
   * If endOffset < startOffset the <code>xmlFragment</code> will be inserted at <code>startOffset</code>.
   * 
   * @param xmlFragment The XML fragment which will surround the given offsets.
   * The first XML fragment leaf(deepest on the first branch) will be the surround point.
   * @param startOffset The start offset of the fragment to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the fragment to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the fragment between the offsets could not be surrounded.
   * @deprecated Use {@link AuthorDocumentController#surroundInFragment(String, int, int)} instead.
   */
  @Deprecated
  void surroundInFragment(String xmlFragment, int startOffset, int endOffset) throws AuthorOperationException;

  /**
   * Surround the given offsets in plain text(without XML parsing) by inserting the header
   * at the start offset and the footer at the endOffset.
   * 
   * @param header The header to be inserted before the surrounded text.
   * @param footer The footer to be inserted after the surrounded text.
   * @param startOffset The start offset of the text to be surrounded, 0 based.
   * @param endOffset The end offset of the text to be surrounded, zero based.
   * @deprecated Use {@link AuthorDocumentController#surroundInText(String, String, int, int)} instead.
   */
  @Deprecated
  void surroundInText(String header, String footer, int startOffset, int endOffset);

  /**
   * Move the caret to the specified offset.
   * 
   * @param offset The offset where the caret should be positioned, 0 based.
   * @deprecated Use {@link AuthorEditorAccess#setCaretPosition(int)} instead.
   */
  @Deprecated
  void setCaretPosition(int offset);
  
  /**
   * Select the interval between start and end offset.
   *  
   * @param startOffset Inclusive start offset 
   * @param endOffset  Exclusive end offset
   * @deprecated Use {@link AuthorEditorAccess#select(int, int)} instead.
   */
  @Deprecated
  void select(int startOffset, int endOffset);

  /**
   * Compute the offsets of the word that contains the caret position.
   * 
   * @return An array with the start and end offsets of the word at caret.
   * <code>null</code> if the offsets couldn't be obtained.
   * @deprecated Use {@link AuthorEditorAccess#getWordAtCaret()} instead.
   */
  @Deprecated
  int[] getWordAtCaret();

  /**
   * Returns the parent frame.
   * 
   * @return The parent frame ({@link javax.swing.JFrame or @link java.awt.Frame (when running as a JApplet)}) of the Oxygen application or the parent shell(Shell) 
   * if this is the Eclipse implementation.
   * @deprecated Use {@link AuthorWorkspaceAccess#getParentFrame()} instead.
   */
  @Deprecated
  Object getParentFrame();
    
  /**
   * Make the child path relative to the parent.
   * <p>
   * The child path is relatively expressed to the base file. If is
   * not possible, the child URL is returned.</p> 
   * <p>
   * Ex: Base: "file://c:/projects/exml/base.prx", Child
   * "file://c:/projects/exml/test/someTest.xml"</p> <p>
   *
   * Result: "test/someTest.xml"</p> 
   * 
   * @param baseURL The base URL.
   * @param childURL The child URL.
   * @return The relative path or the <code>childURL</code> if a relative path 
   * cannot be computed.
   * @deprecated Use {@link AuthorUtilAccess#makeRelative(URL, URL)} instead.
   */
  @Deprecated
  String makeRelative(URL baseURL, URL childURL);
  
  /**
   * Escape an attribute value so that the XML remains wellformed.
   * 
   * @param attributeValue The attribute value.
   * @return The escaped value.
   * @deprecated Use {@link AuthorUtilAccess#escapeAttributeValue(String)} instead.
   */
  @Deprecated
  String escapeAttributeValue(String attributeValue);
  
  /**
   * Get the editor location.
   * 
   * @return The editor location.
   * @deprecated Use {@link AuthorEditorAccess#getEditorLocation()} instead.
   */
  @Deprecated
  URL getEditorLocation();
  
  /**
   * Locate the file on disk corresponding to the URL.
   * 
   * @param url The URL to be checked.
   * @return The corresponding file or <code>null</code> if URL is remote.
   * @deprecated Use {@link AuthorUtilAccess#locateFile(URL)} instead.
   */
  @Deprecated
  File locateFile(URL url);
  
  /**
   * Choose a file.
   * 
   * @param title The file chooser title.
   * @param allowedExtensions Allowed file extensions.
   * @param filterDescr Description for this file filter.
   * @param openForSave True to show the file chooser for saving, false to use it for opening 
   * @return The chosen file or <code>null</code> if user canceled the dialog...
   * @deprecated Use {@link AuthorWorkspaceAccess#chooseFile(String, String[], String, boolean)} instead.
   */
  @Deprecated
  File chooseFile(String title, String[] allowedExtensions, String filterDescr, boolean openForSave);
  
  /**
   * Choose a file.
   * 
   * @param title The file chooser title.
   * @param allowedExtensions Allowed file extensions.
   * @param filterDescr Description for this file filter.
   * @return The chosen file or <code>null</code> if user canceled the dialog...
   * @deprecated Use {@link AuthorWorkspaceAccess#chooseURL(String, String[], String)} instead.
   */
  @Deprecated
  File chooseFile(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Choose an url.
   * 
   * @param title The file chooser title.
   * @param allowedExtensions Allowed extensions.
   * @param filterDescr Description for this file filter.
   * @return The chosen url or <code>null</code> if user canceled the dialog...
   * @deprecated Use {@link AuthorWorkspaceAccess#chooseURL(String, String[], String)} instead.
   */
  @Deprecated
  URL chooseURL(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Find the cell included into the previous row that has the same column index.
   * 
   * @param cellElement The table cell element.
   * @return The cell above. Can be <code>null</code>.
   * @deprecated Use {@link AuthorTableAccess#getTableCellAbove(AuthorElement)} instead.
   */
  @Deprecated
  AuthorElement getTableCellAbove(AuthorElement cellElement);
  
  /**
   * Find the cell included into the next row that has the same column index.
   * 
   * @param cellElement The table cell element.
   * @return The cell bellow. Can be <code>null</code>.
   * @deprecated Use {@link AuthorTableAccess#getTableCellBelow(AuthorElement)} instead.
   */
  @Deprecated
  AuthorElement getTableCellBelow(AuthorElement cellElement);
  
  /**
   * Obtain the table row and column index for the given element.
   * 
   * @param authorElement The element.
   * @return an array with row index on the first position and column index on the second one. 
   * 0 based. Can be <code>null</code>.
   * @deprecated Use {@link AuthorTableAccess#getTableCellIndex(AuthorElement)} instead.
   */
  @Deprecated
  int[] getTableCellIndex(AuthorElement authorElement);
  
  /**
   * Obtain the element at the given row and column in the table.
   * 
   * @param row The row, 0 based.
   * @param column The column, 0 based.
   * @param tableElement The table element.
   * @return The element at the specified location. Can be <code>null</code> if it could not be 
   * found.
   * @deprecated Use {@link AuthorTableAccess#getTableCellAt(int, int, AuthorElement)} instead.
   */
  @Deprecated
  AuthorElement getTableCellAt(int row, int column, AuthorElement tableElement);

  /**
   * Find the table row element for the given index.
   * 
   * @param index The index of the row to find, 0 based.
   * @param tableElement The table element.
   * @return The table row. Can be <code>null</code>.
   * @deprecated Use {@link AuthorTableAccess#getTableRow(int, AuthorElement)} instead.
   */
  @Deprecated
  AuthorElement getTableRow(int index, AuthorElement tableElement);
  
  /**
   * Get the row count for the table. 
   * 
   * @param tableElement The table element.
   * @return The row count.
   * @deprecated Use {@link AuthorTableAccess#getTableRowCount(AuthorElement)} instead.
   */
  @Deprecated
  int getTableRowCount(AuthorElement tableElement);

  /**
   * Returns the number of columns for the given table element.
   * 
   * @param tableElement The table element.
   * @return The number of columns.
   * @deprecated Use {@link AuthorTableAccess#getTableNumberOfColumns(AuthorElement)} instead.
   */
  @Deprecated
  int getTableNumberOfColumns(AuthorElement tableElement);

  /**
   * For the given cell find the start column and the end column defining the column span. 
   * The indices are 0 based.
   * 
   * @param cellElement The table cell element.
   * @return The column span indices. Can be <code>null</code>.
   * @deprecated Use {@link AuthorTableAccess#getTableColSpanIndices(AuthorElement)} instead.
   */
  @Deprecated
  int[] getTableColSpanIndices(AuthorElement cellElement);
  
  /**
   * Returns information about the Oxygen underlying implementation.
   * 
   * @return <code>true</code> if this is the standalone Oxygen version,
   * <code>false</code> if this is the Oxygen Eclipse plugin version.
   * @deprecated Use {@link AuthorWorkspaceAccess#isStandalone()} instead.
   */
  @Deprecated
  boolean isStandalone();

  /**
   * Test if the context at the given <code>offset</code> is inline or not. 
   * 
   * For example a text paragraph determines an inline context, 
   * and for an offset inside this paragraph the method will return <code>true</code>. 
   * For an offset between two paragraphs(block boxes) the method will returns <code>false</code>.
   * 
   * @param offset The offset in the document, zero based.
   * @return Returns <code>true</code> if the given offset is inside an inline context.
   * <code>false</code> otherwise.
   * @throws BadLocationException When the offset does not exists in document model.
   * @deprecated Use {@link AuthorDocumentController#inInlineContext(int)} instead.
   */
  @Deprecated
  boolean inInlineContext(int offset) throws BadLocationException;

  /**
   * Insert multiple empty elements at the given offsets.
   * The offsets and elements must be in the document order.
   * 
   * @param parentElement The element that will be the parent of the inserted elements. 
   * @param elementNames The element names to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted.
   * @param namespace The namespace of the new inserted elements. <code>null</code> for default namespace.
   * @deprecated Use {@link AuthorDocumentController#insertMultipleElements(AuthorElement, String[], int[], String)} instead.
   */
  @Deprecated
  void insertMultipleElements(AuthorElement parentElement, String[] elementNames, int[] offsets, String namespace);
  
  /**
   * Deletes the given intervals. The offsets must be in document order and the intervals 
   * must not intersect with one another.
   * 
   * @param parentElement The element that contains all the deleted intervals.
   * @param startOffsets The start offset for each interval. Must be in document order.
   * @param endOffsets The end offset for each interval. Must be in document order.
   * @deprecated Use {@link AuthorDocumentController#multipleDelete(AuthorElement, int[], int[])} instead.
   */
  @Deprecated
  void multipleDelete(AuthorElement parentElement, int[] startOffsets, int[] endOffsets);
  
  /**
   * Remove the attribute from a cloned element.
   * Warning: Use this only when the element is not from the existing content.
   * All operations on nodes from the document model must be done through the AuthorDocumentController.  
   * 
   * @param element Element node.
   * @param attrName The attribute name to remove.
   * @deprecated Use {@link AuthorElement#removeAttribute(String)} instead.
   */
  @Deprecated
  void removeClonedElementAttribute(AuthorElement element, String attrName);
  
  /**
   * Set the attribute value for a cloned element.
   * Warning: Use this only when the element is not from the existing content.
   * All operations on nodes from the document model must be done through the AuthorDocumentController.  
   * 
   * @param element Element node.
   * @param name Name of the attribute to be set.
   * @param attributeValue The attribute value to set. Must not be <code>null</code>.
   * @deprecated Use {@link AuthorElement#setAttribute(String, AttrValue)} instead.
   */
  @Deprecated
  void setClonedElementAttribute(AuthorElement element, String name, AttrValue attributeValue);
  
  /**
   * Shows a question message.
   * 
   * @param title The dialog title.
   * @param message The message to be presented to the user.
   * @param buttonNames The names of the buttons representing the choices.
   * @param buttonIds The id for each button. Used to identify which button was pressed.
   * All ids must be greater or equal to 0.
   * 
   * @return the id of the pressed button or -1 if the dialog was closed by other means.
   * @deprecated Use {@link AuthorWorkspaceAccess#showConfirmDialog(String, String, String[], int[])} instead.
   */
  @Deprecated
  int showConfirmDialog(String title, String message,
      String[] buttonNames, int[] buttonIds);
  
  /**
   * Creates an XML Reader without validation.
   * 
   * @return A new XML Reader.
   * @deprecated Use {@link AuthorUtilAccess#newNonValidatingXMLReader()} instead.
   */
  @Deprecated
  XMLReader newNonValidatingXMLReader();
  
  /**
   * Corrects the given URL.
   * 
   * @param url The URL to be corrected.
   * @return The corrected URL.
   * @deprecated Use {@link AuthorUtilAccess#correctURL(String)} instead.
   */
  @Deprecated
  String correctURL(String url);

  /**
   * Presents the error message.
   * 
   * @param message The error message to be presented.
   * @deprecated Use {@link AuthorWorkspaceAccess#showErrorMessage(String)} instead.
   */
  @Deprecated
  void showErrorMessage(String message);

  /**
   * Try to resolve a relative href to an absolute path by passing through catalog.
   * 
   * @param baseURL The URL of the current opened XML file.
   * @param relativeLocation The relative href.
   * @param entityResolve True to pass through catalog entity resolver
   * @param uriResolve True to pass through catalog URI resolver.
   * @return The absolute URL.
   * @deprecated Use {@link AuthorUtilAccess#resolvePath(URL, String, boolean, boolean)} instead.
   */
  @Deprecated
  URL resolvePath(URL baseURL, String relativeLocation, boolean entityResolve, boolean uriResolve);
 
  /**
   * Finds the author nodes selected by the given XPath expression.
   * The result of this function is an array of AuthorNode's selected by the given XPath expression.
   * Author text nodes, Author CDATA section nodes and Author comment nodes can be ignored for performance reasons.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the AuthorNode's in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   * 
   * 
   * @param xpathExpression The XPath expression.
   * @param ignoreTexts If <code>true</code> Author text nodes will not be returned.
   * @param ignoreCData If <code>true</code> Author CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> Author comments will not be returned.
   * @return The Author nodes selected by the XPath expression.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   * @deprecated Use {@link AuthorDocumentController#findNodesByXPath(String, boolean, boolean, boolean)} instead.
   */
  @Deprecated
  AuthorNode[] findNodesByXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Evaluates an XPath expression.
   * This functions returns the result of the given XPath expression as an array of Object's.
   * Author DOM text nodes, DOM CDATA sections and DOM comments wrappers can be ignored for performance reasons.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the Author DOM Node wrappers in the document.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all the Author DOM Node wrappers in the document and having as last component
   * the total number of nodes.
   * 
   * @param xpathExpression The XPath expression.
   * @param ignoreTexts If <code>true</code> DOM text nodes will not be returned.
   * @param ignoreCData If <code>true</code> DOM CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> DOM comments will not be returned.
   * @return An array of objects representing the XPath result.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   * @deprecated Use {@link AuthorDocumentController#evaluateXPath(String, boolean, boolean, boolean)} instead.
   */
  @Deprecated
  Object[] evaluateXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Add an Author listener to be notified about changes regarding document and document structure.
   * 
   * @param listener The listener to be added.
   * @deprecated Use {@link AuthorDocumentController#addAuthorListener(AuthorListener)} intead. 
   */
  @Deprecated
  void addAuthorListener(AuthorListener listener);
  
  /**
   * Remove an Author listener.
   * 
   * @param listener The listener to be removed.
   * @deprecated Use {@link AuthorDocumentController#removeAuthorListener(AuthorListener)} intead. 
   */
  @Deprecated
  void removeAuthorListener(AuthorListener listener);
  
  /**
   * Get the position in the document corresponding to the point in the viewport.
   * 
   * @param x The "x" coordinate relative to the viewport origin.
   * @param y The "y" coordinate relative to the viewport origin.
   * @return  The information about the view-at-position.
   * @deprecated Use {@link AuthorEditorAccess#viewToModel(int, int)} instead.
   */
  @Deprecated
  AuthorViewToModelInfo viewToModel(int x, int y);
  
  /**
   * Return <code>true</code> if the current editor is in change tracking mode
   * 
   * @return <code>true</code> if the current editor is in change tracking mode
   * @deprecated Use {@link AuthorChangeTrackingController#isTrackingChanges()} instead. 
   */
  @Deprecated
  boolean isTrackingChanges();
  
  /**
   * Toggle the track changes mode.
   * @deprecated Use {@link AuthorChangeTrackingController#toggleTrackChanges()} instead.
   */
  @Deprecated
  void toggleTrackChanges();

  /**
   * The change tracking controller used to toggle change tracking on and off and
   * check its state.
   * 
   * @return The change tracking controller. Cannot be <code>null</code>.
   *
   * @deprecated Use <code>{@link AuthorAccess#getReviewController()}</code> instead.
   */  
  @Deprecated
  AuthorChangeTrackingController getChangeTrackingController();
}