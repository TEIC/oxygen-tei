/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.net.URL;
import java.util.List;

import javax.swing.text.BadLocationException;

import ro.sync.contentcompletion.xml.CIAttribute;
import ro.sync.contentcompletion.xml.CIElement;
import ro.sync.contentcompletion.xml.CIValue;
import ro.sync.contentcompletion.xml.Context;
import ro.sync.contentcompletion.xml.NameValue;
import ro.sync.contentcompletion.xml.WhatAttributesCanGoHereContext;
import ro.sync.contentcompletion.xml.WhatElementsCanGoHereContext;
import ro.sync.contentcompletion.xml.WhatPossibleValuesHasAttributeContext;
import ro.sync.ecss.component.AuthorSchemaAwareOptions;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * Author schema manager. Provides support for obtaining information about what elements, attributes can be inserted 
 * in a given context.
 */
public interface AuthorSchemaManager {
  /**
   * Defines LAX validation of the elements from a fragment in a given context (they are found in the
   * list of possible children of the context element).
   */
  public static final short VALIDATION_MODE_LAX = 1;
  /**
   * Defines STRICT validation for the first element from the fragment in a given context (it is accepted by the parent in 
   * the exact position he is about to be inserted) and LAX validation for all other siblings (they are found in the
   * list of possible children of the context element).
   */
  public static final short VALIDATION_MODE_STRICT_FIRST_CHILD_LAX_OTHERS = 4;
  
  /**
   * Check if the given fragment can be inserted at the given offset with respect to the given validation mode.
   * 
   * @param fragment Author fragment.
   * @param offset The offset where to check if the fragment can be inserted.
   * @param validationMode VALIDATION_MODE_LAX or VALIDATION_MODE_STRICT_FIRST_CHILD_LAX_OTHERS.
   * 
   * @return <code>true</code> if the fragment can be inserted with respect to the given validation mode.
   */
  boolean canInsertDocumentFragment(AuthorDocumentFragment fragment, int offset, short validationMode);
  
  /**
   * Check if the given fragments can be inserted at the given offset with respect to the given validation mode.
   * 
   * @param fragments Author fragment.
   * @param offset The offset where to check if the fragments can be inserted.
   * @param validationMode VALIDATION_MODE_LAX or VALIDATION_MODE_STRICT_FIRST_CHILD_LAX_OTHERS.
   * 
   * @return <code>true</code> if the fragments can be inserted with respect to the given validation mode.
   */
  boolean canInsertDocumentFragments(AuthorDocumentFragment[] fragments, int offset, short validationMode);
  /**
   * Check if the element at the given offset accepts text (in other words element content type is not ELEMENT ONLY or EMPTY). 
   * 
   * @param offset The offset where to check if text can be inserted.
   * @return <code>true</code> if text can be inserted at the given offset.
   */
  boolean canInsertText(int offset);
  /**
   * Check if the given fragments can be inserted in the given context with respect to the given validation mode. The 
   * insertion context will also be used for resolving namespaces for the nodes inside the fragment.
   * 
   * @param fragments Author fragments.
   * @param insertionContext Insertion context.
   * @param authorNode The corresponding node for the given context.
   * @param validationMode VALIDATION_MODE_LAX or VALIDATION_MODE_STRICT_FIRST_CHILD_LAX_OTHERS.
   * 
   * @return <code>true</code> if the fragment can be inserted with respect to the given validation mode.
   */
  boolean canInsertDocumentFragments(
      AuthorDocumentFragment[] fragments, 
      WhatElementsCanGoHereContext insertionContext, 
      short validationMode);
  
  /**
   * Create an element context for the given offset.
   * 
   * @param offset Offset in document for which to create an element context.
   * @return The element context. Null value will be returned if node at given offset is not an element.
   * @throws BadLocationException When the offset is below zero or greater than the content.
   */
  WhatElementsCanGoHereContext createWhatElementsCanGoHereContext(int offset) throws BadLocationException;
  /**
   * Create a context for the given element that can be used to obtain the list with attributes that element accepts.
   * 
   * @param element The element to to create {@link WhatAttributesCanGoHereContext}
   * @return An attribute context.
   * @see #whatAttributesCanGoHere(WhatAttributesCanGoHereContext)
   */
  WhatAttributesCanGoHereContext createWhatAttributesCanGoHereContext(AuthorElement element);
  /**
   * Create an attribute values context for the given element and attribute name.
   * 
   * @param element The element whose attribute values interest us.
   * @param attributeName The name of attribute to create context.
   * @return An attribute values context.
   */
  WhatPossibleValuesHasAttributeContext createWhatPossibleValuesHasAttributeContext(AuthorElement element, String attributeName);
  /**
   * @return Schema aware options values.
   */
  AuthorSchemaAwareOptions getAuthorSchemaAwareOptions();
  /**
   * Examines the grammar and decides what attributes can be inserted in the
   * parent element, after the list of attributes names.
   *
   * @param whatAttributesCanGoHereContext the context for the call. It must
   * have:
   * <ul>
   *  <li>elementName              the name of the element in which will be
   *      done the insertion.</li>
   *  <li>proxyNamespaceMapping    the proxy - uri mappings defined before the
   *      insertion point.</li>
   *  <li>previousAttributesNames  the names of the existing attributes in the
   *      element, attributes that are before the insertion point.</li>
   * </ul>
   *@return                     a list of attributes or null if there is none. 
   *Null value is also returned when schema is not specified.
   *@see #createWhatAttributesCanGoHereContext(AuthorElement)
   */
  List<CIAttribute> whatAttributesCanGoHere(WhatAttributesCanGoHereContext whatAttributesCanGoHereContext);
  /**
   * Examines the grammar and decides what elements can be inserted in the
   * parent element, after the list of child names.
   *
   * @param whatElementsCanGoHereContext the context for the call. It must have:
   * <ul>
   *  <li>parentElementName the qName of the parent element</li>
   *  <li>previousElementNames the list of qNames of the previous elements</li>
   *  <li>previousElementNamespaces the list of qNames of the previous elements</li>
   *  <li>proxyNamespaceMapping    the proxy - uri mappings defined before the
   *      insertion point.</li>
   *@return                      a list of CIElement representing the elements,
   * or null if there is none. Null value is also returned when schema is not specified.
   */
  List<CIElement> whatElementsCanGoHere(WhatElementsCanGoHereContext whatElementsCanGoHereContext);
  /**
   * Queries the possible values of an element attribute. If the
   * attribute type was an enumeration, then a list with the tokens of the
   * enumeration will be returned.
   * @param ctxt The context WhatPossiBleValuesHasAttributeContext.
   *
   * @return the list of CIValue representing possible values of 
   * the attribute or null if they are not known. Null value is also returned when schema is not specified.
   */
  List<CIValue> whatPossibleValuesHasAttribute(WhatPossibleValuesHasAttributeContext ctxt);
  /**
   * Queries the possible values of an element. If the element type was an enumeration,
   * then a list with the tokens of the enumeration will be returned.
   * 
   * @param ctxt The context.
   * @return a list of attribute values as CIValue or null if there is none or no schema is specified.
   * The list of values can contain duplicates.
   */
  public List<CIValue> whatPossibleValuesHasElement(WhatElementsCanGoHereContext ctxt);
  
  /**
   * Get the array of URLs of the loaded DTD or XML Schema. These URLs were set
   * using one of the update methods, and includes the URLs that were collected from the calls
   * of the <code>update(InputSource[])</code> methods.
   *
   *@return The URLs of the schemas loaded, or null if there was nothing loaded.
   */
  URL[] getGrammarURLs();
  
  /**
   * Get the description of an attribute. This model must be human readable.
   *
   * @param ctxt the context describing the target attribute.
   * @return a hash describing the model of the element.
   */
  CIAttribute getAttributeDescription(WhatPossibleValuesHasAttributeContext ctxt);
  
  /**
   * Gets the context-independent list of entities declared in the document's 
   * DOCTYPE declaration.<p> 
   * If the DOCTYPE declaration is not changed, the document should not be
   * processed each time this method is called.
   *
   * @return a list of name value representing the entities, or null if
   *          there is none. The reference of the list is changed on update.
   */
  List<NameValue> getEntities();
  
  /**
   * Get the description of an element. This model must be human readable.
   *
   * @param ctxt the context describing the target element. It contains:<ul>
   *  <li>The element names stack, having at top the current element name.</li>
   *  <li>The element namespaces stack, having at top the current element namespace.</li>
   * </ul>
   * @return a description the model of the element, or null.
   */
  CIElement getElementDescription(Context ctxt);
  
  /**
   * If true the element description(model) support is available, otherwise not.
   * @return True if element description is supported by the SM.
   */
  boolean isElementDescriptionSupported();
  
  /**
   * Get the elements that can be children of the element for
   * which the context was built.
   * 
   * @param context The element context.
   * @return A list with CIElements that are allowed as children.
   */
  List<CIElement> getChildrenElements(WhatElementsCanGoHereContext context);
  
  /**
   * Returns true if schema was learned by Oxygen only from the structure of the XML document.
   * This only happens when Oxygen does not detect an associated schema for the XML document 
   * and learns the structure of the XML file directly.
   * 
   * @return Return true if schema was learned by Oxygen only from the structure of the XML document.
   */
  boolean isLearnSchema();
  
  /**
   * @return Return true if there were errors when loading schema document(missing, not wellformed, not valid schema).
   */
  boolean hasLoadingErrors();
  
  /**
   * Create an author document fragment from a CIElement
   * @param element The CI Element from which to create a full fragment which can be inserted
   * @return The created document fragment.
   * @throws BadLocationException
   * @since 11.2  
   */
  AuthorDocumentFragment createAuthorDocumentFragment(CIElement element) throws BadLocationException;
  
  /**
   * Get all the names of global elements defined in the associated grammar.
   *
   * @return A list of CIElements.
   * @since 11.2
   */
  List<CIElement> getGlobalElements();
  
  /**
   * Get all the elements, including eventual local ones.
   * We need this for instance if providing content completion
   * proposals as a result schema manager for XSLT.
   *
   * @return A list of CIElement.
   * 
   * @since 12.1
   */
  List<CIElement> getAllPossibleElements();
}
