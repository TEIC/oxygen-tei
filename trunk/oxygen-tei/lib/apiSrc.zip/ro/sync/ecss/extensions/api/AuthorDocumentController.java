/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Position;
import javax.swing.text.Segment;
import javax.swing.undo.UndoManager;

import ro.sync.ecss.extensions.api.content.ClipboardFragmentProcessor;
import ro.sync.ecss.extensions.api.content.OffsetInformation;
import ro.sync.ecss.extensions.api.content.RangeProcessor;
import ro.sync.ecss.extensions.api.content.TextContentIterator;
import ro.sync.ecss.extensions.api.filter.AuthorFilteredContent;
import ro.sync.ecss.extensions.api.filter.AuthorNodesFilter;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorDocument;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.ecss.extensions.api.schemaaware.SchemaAwareHandlerResult;

/**
 * Provides methods for modifying the Author document.
 */
public interface AuthorDocumentController {

  /**
   * Deletes a document fragment between the start and end offset.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.  
   * 
   * @param startOffset Start offset, 0 based, inclusive.
   * @param endOffset End offset, 0 based, inclusive.
   * @return <code>true</code> if the delete operation was successful.
   */
  boolean delete(int startOffset, int endOffset);
  
  /**
   * Delete a node.
   * 
   * @param node The {@link AuthorNode} to delete.
   * @return <code>true</code> if the delete node operation was successful. 
   */
  boolean deleteNode(AuthorNode node);
  
  /**
   * Replace the current root element with the new given one. 
   * The fragment must contain only one element, otherwise the replacement will not be performed.
   * 
   * @param fragment The document fragment containing the new root element.
   */
  void replaceRoot(AuthorDocumentFragment fragment);

  /**
   * Create a document fragment for the given range of offsets. The offset ranges must be from the current AuthorDocument.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.  
   * 
   * @param startOffset The start offset, 0 based, inclusive. 
   * @param endOffset The end offset, 0 based, inclusive.
   * @return A new {@link AuthorDocumentFragment}. 
   *         It does not return a <code>null</code> fragment.
   * @throws BadLocationException When the offsets are not between 0 and the 
   * content length, or the <code>startOffset</code> is greater than the <code>endOffset</code>.
   */
  AuthorDocumentFragment createDocumentFragment(int startOffset, int endOffset)
      throws BadLocationException;
  
  /**
   * Create a new {@link AuthorDocumentFragment} from an XML string in a specified context.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.  
   * 
   * @param xmlFragment The XML Fragment.
   * @param contentOffset The offset where the XML fragment should be inserted.
   * @return The newly created {@link AuthorDocumentFragment}. 
   *         It does not return a <code>null</code> fragment.
   * @throws AuthorOperationException If the new fragment creation fails. 
   */
  AuthorDocumentFragment createNewDocumentFragmentInContext(String xmlFragment, int contentOffset)
      throws AuthorOperationException;
  
  /**
   * Create a new {@link AuthorDocumentFragment} from an string.
   * 
   * @param textFragment The text fragment.
   * @return The newly created {@link AuthorDocumentFragment}. 
   *         It does not return a <code>null</code> fragment.
   * @throws AuthorOperationException If the new fragment creation fails. 
   */
  AuthorDocumentFragment createNewDocumentTextFragment(String textFragment)
      throws AuthorOperationException;
  
  /**
   * Takes the given fragment and serializes it to XML text in the context 
   * of the current document.
   * 
   * The following code example extracts the selection as an XML fragment, 
   * processes and then reinserts it:
   * <p>
   * <hr><blockquote><pre>
   * if(authorAccess.getEditorAccess().hasSelection()) {
   *    AuthorDocumentController documentController = authorAccess.getDocumentController();
   *    AuthorDocumentFragment selectionAsAFragment = documentController.createDocumentFragment(
   *         authorAccess.getEditorAccess().getSelectionStart(), authorAccess.getEditorAccess().getSelectionEnd());
   *    String selectionAsXML = documentController.serializeFragmentToXML(selectionAsAFragment);
   *    
   *    //Deletes the selection
   *    authorAccess.getEditorAccess().deleteSelection();
   *    
   *    //Process the selectionAsXML fragment, modify it.
   *    //................
   *    
   *    //Insert the XML fragment back at caret position.
   *    documentController.insertXMLFragment(selectionAsXML, authorAccess.getEditorAccess().getCaretOffset());
   * }
   * </pre></blockquote><hr>
   * 
   * If the fragment contains change tracking highlights, they will be 
   * serialized as processing instructions.
   * 
   * @param fragment The {@link AuthorDocumentFragment} to serialize.
   * @return An equivalent {@link String} representation of the given fragment.
   *         It does not return a <code>null</code> String. If the fragment cannot be serialized
   *         it will return an empty String.
   * @throws BadLocationException If the serialization could not be accomplished, 
   * usually because the fragment was not properly built.
   */
  String serializeFragmentToXML(AuthorDocumentFragment fragment) throws BadLocationException;

  /**
   * Sets the value of an attribute in the specified element. 
   * Attributes set in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) 
   * will be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute being changed.
   * @param value New {@link AttrValue} for the attribute. If <code>null</code>, the attribute is 
   * removed from the element.
   * @param element The {@link AuthorElement} whose attribute is changing.
   */
  void setAttribute(String attributeName, AttrValue value, AuthorElement element);

  /**
   * Removes an attribute from the given element. 
   * Attributes removed in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) will 
   * be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute to remove.
   * @param element The {@link AuthorElement} whose attribute will be removed.
   */  
  void removeAttribute(String attributeName, AuthorElement element);

  /**
   * Returns the node at the given offset. The given offset must be
   * greater or equal to 0 and less than the current document length.
   * <br/><br/>
   * Note: 
   * <i>If the caret has the offset of an element's start offset marker character, it is considered to be before the element.</i>
   * <br/>
   * <i>If the caret has the offset of an element's end offset marker character, it is considered to be inside the element.</i>
   * <br/><br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.  
   * 
   * @param offset The offset in the content, zero based.
   * @return The {@link AuthorNode} containing the offset, 
   * or <code>null</code> when the actual document is <code>null</code>. 
   * @throws BadLocationException When the offset is negative or greater 
   * than the content length.
   */
  public AuthorNode getNodeAtOffset(int offset) throws BadLocationException;
  
  
  /**
   * Returns content information for the offset. 
   * If the offset is on a marker character the returned result will also contain the node which contains the range indicated by the marker. 
   * 
   * @since 12.2
   * @param offset The offset in the content, zero based.
   *
   * @return content information for the offset.
   * <br/>
   * <img src="content/OffsetInformation.gif"/> 
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.
   * 
   * @throws BadLocationException 
   */
  public OffsetInformation getContentInformationAtOffset(int offset) throws BadLocationException;

  /**
   * Create a document fragment containing a copy of the node. The node must be from the current AuthorDocument.
   * The attributes of the elements will be copied. 
   * If <code>copyContent</code> is <code>true</code> the node content 
   * will be copied also.   
   * 
   * @param node The {@link AuthorNode} to be duplicated.
   * @param copyContent If <code>true</code> the content of the node will 
   * also be duplicated.
   * @return  The {@link AuthorDocumentFragment} containing the duplicated node.
   *          It does not return a <code>null</code> fragment.
   * @throws BadLocationException When the operation fails. 
   */
  AuthorDocumentFragment createDocumentFragment(AuthorNode node, boolean copyContent) throws BadLocationException;
  
  /**
   * Gets a sequence of text from the document text content.
   * The document text content can be obtained by adding all the text nodes
   * content.
   * <br/>
   * The <code>offset</code> is considered to be relative to the
   * text content start offset. So the 0 offset corresponds to the offset of 
   * the first valid char in the document.
   * <br/>
   * The <code>length</code> represents also a number of valid chars encountered
   * after the real start offset was determined.
   * <br/>
   * <br/>
   * For the document:
   * <code>
   * <br/>
   * [?PI?][article][!COMMENT][para]PARAGRAPH[/para][/article]
   * <br/>
   * </code>
   * <br/>
   * <code>getText(0, 18)</code> returns "PICOMMENTPARAGRAPH"
   * <br/>
   * <code>getText(5, 8)</code> returns "MENTPARA"
   *
   * @param offset The starting offset >= 0. 
   * @param length The number of characters to retrieve >= 0
   * @return The text
   * @deprecated  Use the API based on the {@link AuthorNode} to get only the displayed text
   *              without mark-up markers.
   * @exception BadLocationException The range given includes a position 
   *            that is not a valid position within the document text content.
   */
  @Deprecated
  String getText(int offset, int length) throws BadLocationException;
  
  /**
   * Returns the length of the text content of the document. This is the number of valid 
   * characters in the document text. The length
   * can be determined by the adding all text nodes content length.
   * <br/> 
   * <br/>
   * For the document:
   * <code>
   * <br/>
   * [?PI?][article][!COMMENT][para]PARAGRAPH[/para][/article]
   * <br/>
   * </code>
   * 
   * The text content length will be:
   * <br/>
   * <code>
   * "PI".length() + "COMMENT".length() + "PARAGRAPH".length()
   * <br/>
   * 2 + 7 + 9 = 18
   *
   * @deprecated  Use the API based on the {@link AuthorNode} to get the length 
   *              of the displayed text only, without mark-up markers.
   * @return The text content length >= 0
   * @throws BadLocationException
   */
  @Deprecated
  int getTextContentLength() throws BadLocationException;
  
  /**
   * Get access to the Author undo manager.
   * 
   * @return The Author undo manager. The returned undo manager cannot be <code>null</code>.
   */
  UndoManager getUndoManager();
  
  /**
   * Begin a compound edit. This method should be called
   * to signal to the editing support that a complex editing operation begins.
   * The editing operations that occur between <code>beginCompoundEdit()</code>
   * and <code>endCompoundEdit()</code> methods calls are regarded by the UndoManager 
   * as a single operation which can be undone/redone in one step.
   */
  void beginCompoundEdit();
  
  /**
   * End a compound edit. This method should be called
   * to signal to the editing support that a complex editing operation ends.
   * @see #beginCompoundEdit()
   */
  void endCompoundEdit();

  /**
   * Cancel the current compound edit. This method should be called
   * to signal to the editing support that all edits performed so far inside a current compound edit must be undo.
   * The editing operations that occurred after the previous call to <code>beginCompoundEdit()</code>
   * will be undo by the UndoManager.
   * @see #beginCompoundEdit()
   * @see #endCompoundEdit()
   */
  void cancelCompoundEdit();
  
  /**
   * Inserts a text at the given offset. After the operation the caret will be 
   * positioned at the end of the inserted text.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges. 
   * 
   * @param offset The insert position, 0 based.
   * @param text The text to be inserted.
   */
  void insertText(int offset, String text);
  
  /**
   * Insert an XML fragment at the given offset. 
   * After the operation the caret will be positioned at the end of the 
   * inserted XML fragment.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges. 
   * 
   * @param xmlFragment The XML fragment to insert.
   * @param offset The insert position, 0 based.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  void insertXMLFragment(String xmlFragment, int offset) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment relative to the node identified by the <code>xpathLocation</code> 
   * and according with the <code>relativePosition</code>.
   * Note: if the <code>xpathLocation</code> is not specified then the XML fragment 
   * will be inserted at caret position and the <code>relativePosition<code> will be ignored. 
   * <p>
   * After the operation the caret will be positioned at the end of the inserted XML fragment. 
   * 
   * @param xmlFragment The XML fragment.
   * @param xpathLocation The XPath location.
   * @param relativePosition The position relative to the node identified by the XPath location. 
   * Can be one of the constants: {@link AuthorConstants#POSITION_BEFORE}, {@link AuthorConstants#POSITION_AFTER}, 
   * {@link AuthorConstants#POSITION_INSIDE_FIRST} or {@link AuthorConstants#POSITION_INSIDE_LAST}.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  void insertXMLFragment(String xmlFragment, String xpathLocation, String relativePosition) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment relative to the given node and according with the <code>relativePosition</code>.
   * <p>
   * After the operation the caret will be positioned at the end of the inserted XML fragment. 
   * 
   * @param xmlFragment The XML fragment.
   * @param relativeTo The node to insert fragment relative to.
   * @param relativePosition The position relative to the node. 
   * Can be one of the constants: {@link AuthorConstants#POSITION_BEFORE}, {@link AuthorConstants#POSITION_AFTER}, 
   * {@link AuthorConstants#POSITION_INSIDE_FIRST} or {@link AuthorConstants#POSITION_INSIDE_LAST}.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  void insertXMLFragment(String xmlFragment, AuthorNode relativeTo, String relativePosition) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment at the given offset in schema aware mode. 
   * A normal insertion is executed when no schema is specified or schema aware feature is disable by the user
   * (see Preferences / Editor / Pages / Author / Schema aware).
   * 
   * If the fragments insertion is not allowed, a dialog will be shown proposing one of following solutions if they apply:
   * <ul>
   *   <li>insert the fragments inside a new element. The name of the element to wrap the fragments in is computed by analyzing the 
   *   left or right siblings. 
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;emphasis&gt;text&lt;/emphasis&gt;</code> the proposal is to 
   *    create a new <code>para</code> element and insert the fragment inside it. The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  &lt;para&gt;&lt;emphasis&gt;text&lt;/emphasis&gt;&lt;/para&gt;
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre>    
   *   </li>
   *   
   *   
   *   
   *   <li>split an ancestor of the node at insertion offset and insert the fragments between the resulted elements.
   *   
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;sect1&gt;...section content...&lt;/sect1&gt;</code> the proposal is to 
   *    split the parent <code>sect1</code> element and insert the fragment between the resulted sections. The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *&lt;/sect1&gt;
   *&lt;sect1&gt;...section content...&lt;/sect1&gt;
   *&lt;sect1&gt;
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;</pre></li>
   *    
   *    
   *    
   *   <li>insert the fragments somewhere in the proximity of the insertion offset(left or right without skipping content).
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;emphasis&gt;text&lt;/emphasis&gt;</code> the proposals are to 
   *    insert the fragment at the end of <code>title</code> or at beginning of <code>para</code> element.
   *</li>
   *   
   *   
   *   <li>insert at offset the plain text resulted after removing the mark-up.
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title {caret}&lt;/title&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;para&gt;fragment &lt;emphasis&gt;content&lt;/emphasis&gt;&lt;/para&gt;</code> 
   *    the proposal is to remove the fragment mark-up and insert the text 'fragment content' at caret position. 
   *    The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title fragment content&lt;/title&gt;
   *&lt;/sect1&gt;
   *    </pre>       
   *    </li>
   *   
   *   
   *   <li>insert the fragments at insertion offset, even they are not allowed.</li>
   * </ul>
   * 
   * <p>If the developer specifies an {@link AuthorSchemaAwareEditingHandler} then this handler has priority 
   * for executing the insert operation.</p>
   * 
   * @param xmlFragment The XML fragment to insert.
   * @param offset The insert position, 0 based.
   * @return The result of the schema aware insertion. 
   * Can be used to get the insertion offset for the given fragments.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  public SchemaAwareHandlerResult insertXMLFragmentSchemaAware(String xmlFragment, int offset) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment at the given offset in schema aware mode. 
   * A normal insertion is executed when no schema is specified or schema aware feature is disable by the user
   * (see Preferences / Editor / Pages / Author / Schema aware).
   * 
   * If the fragments insertion is not allowed, a dialog will be shown proposing one of following solutions if they apply:
   * <ul>
   *   <li>insert the fragments inside a new element. The name of the element to wrap the fragments in is computed by analyzing the 
   *   left or right siblings. 
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;emphasis&gt;text&lt;/emphasis&gt;</code> the proposal is to 
   *    create a new <code>para</code> element and insert the fragment inside it. The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  &lt;para&gt;&lt;emphasis&gt;text&lt;/emphasis&gt;&lt;/para&gt;
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre>    
   *   </li>
   *   
   *   
   *   
   *   <li>split an ancestor of the node at insertion offset and insert the fragments between the resulted elements.
   *   
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;sect1&gt;...section content...&lt;/sect1&gt;</code> the proposal is to 
   *    split the parent <code>sect1</code> element and insert the fragment between the resulted sections. The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *&lt;/sect1&gt;
   *&lt;sect1&gt;...section content...&lt;/sect1&gt;
   *&lt;sect1&gt;
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;</pre></li>
   *    
   *    
   *    
   *   <li>insert the fragments somewhere in the proximity of the insertion offset(left or right without skipping content).
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title&lt;/title&gt;
   *  {caret}
   *  &lt;para&gt;para content&lt;/para&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;emphasis&gt;text&lt;/emphasis&gt;</code> the proposals are to 
   *    insert the fragment at the end of <code>title</code> or at beginning of <code>para</code> element.
   *</li>
   *   
   *   
   *   <li>insert at offset the plain text resulted after removing the mark-up.
   *   <br> By example, for the next Docbook situation:
   *   <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title {caret}&lt;/title&gt;
   *&lt;/sect1&gt;
   *    </pre> if insert a fragment like: <code>&lt;para&gt;fragment &lt;emphasis&gt;content&lt;/emphasis&gt;&lt;/para&gt;</code> 
   *    the proposal is to remove the fragment mark-up and insert the text 'fragment content' at caret position. 
   *    The proposal result will be:
   *    <pre>&lt;sect1&gt;
   *  &lt;title&gt;Section title fragment content&lt;/title&gt;
   *&lt;/sect1&gt;
   *    </pre>       
   *    </li>
   *   
   *   
   *   <li>insert the fragments at insertion offset, even they are not allowed.</li>
   * </ul>
   * 
   * <p>If the developer specifies an {@link AuthorSchemaAwareEditingHandler} then this handler has priority 
   * for executing the insert operation.</p>
   * 
   * @param xmlFragment The XML fragment to insert.
   * @param offset The insert position, 0 based.
   * @param replaceSelection <code>true</code> to replace the selected Author content with the fragment, 
   * <code>false</code> to leave the selected content and paste at caret position.
   * @return The result of the schema aware insertion. 
   * Can be used to get the insertion offset for the given fragments.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  public SchemaAwareHandlerResult insertXMLFragmentSchemaAware(String xmlFragment, int offset, boolean replaceSelection) throws AuthorOperationException;
  
  /**
   * Insert an {@link AuthorDocumentFragment} at the given offset.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges. 
   * 
   * @param insertOffset The offset where the fragment will be inserted, 0 based.
   * @param frag The {@link AuthorDocumentFragment} to be inserted.
   */
  void insertFragment(int insertOffset, AuthorDocumentFragment frag);
  
  /**
   * This method is useful if you want to make text processing on a given Author selection.
   * You will receive a call back which will give you the AuthorDocumentFragment to process.
   * When finished, the range will be replaced with the processed fragment. 
   * 
   * <p>The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.</p>
   * <p>The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * <code>AuthorNode.getStartOffset()</code> and <code>AuthorNode.getEndOffset()</code>.</p>
   * <br>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <p>The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.</p>
   *
   * @param startOffset     Start offset of the processed range (inclusive).
   * @param endOffset       End offset of the processed range (inclusive).
   * @param rangeProcessor  The range processor which gets notified to process the
   *                        {@link AuthorDocumentFragment}.
   * 
   * @return <code>true</code> if the modifications were merged back in the Author content. 
   * For example when the selection cannot be replaced (inside a not-editable element) this method
   * can return <code>false</code>.
   *
   * @throws BadLocationException 
   * @throws AuthorOperationException 
   * 
   * @since 12.2
   */
  boolean processContentRange(int startOffset, int endOffset, RangeProcessor rangeProcessor) throws BadLocationException, AuthorOperationException;
  
  /**
   * Insert an {@link AuthorDocumentFragment} at the given offset in schema aware mode. 
   * A normal insertion is executed when no schema is specified or schema aware feature is disable by the user
   * (see Preferences / Editor / Pages / Author / Schema aware).
   * <p>For more details about schema aware solutions see comments from {@link #insertXMLFragmentSchemaAware(String, int)} method.</p>
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges. 
   * 
   * @param insertOffset The offset where the fragment will be inserted, 0 based.
   * @param frag The {@link AuthorDocumentFragment} to be inserted.
   * @return The result of the schema aware insertion. 
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  SchemaAwareHandlerResult insertFragmentSchemaAware(int insertOffset, AuthorDocumentFragment frag) throws AuthorOperationException;
  
  /**
   * Surround the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.
   * 
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the content between start and end offset could not be surrounded.
   */
  void surroundInFragment(String xmlFragment, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Surround the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.
   * 
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the content between start and end offset could not be surrounded.
   * 
   * @since 12.1
   */
  void surroundInFragment(AuthorDocumentFragment xmlFragment, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Surround the content between the given offsets with plain text fragments(without XML parsing). 
   * The method inserts the <code>header</code> at <code>startOffset</code> and 
   * the <code>footer</code> at <code>endOffset</code>.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.
   * 
   * @param header The header to be inserted before the surrounded text.
   * @param footer The footer to be inserted after the surrounded text.
   * @param startOffset The start offset of the text to be surrounded, 0 based.
   * @param endOffset The end offset of the text to be surrounded, 0 based.
   * @throws AuthorOperationException If the operation failed.
   */
  void surroundInText(String header, String footer, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Test if the context at the given <code>offset</code> is <b>inline</b> or not. 
   * <p>
   * For example a text paragraph determines an <b>inline</b> context, 
   * and for an offset inside this paragraph the method will return <code>true</code>. 
   * For an offset between two paragraphs (considered to be <b>block</b> level) 
   * the method will return <code>false</code>.
   * 
   * @param offset The offset in the document, zero based.
   * @return Returns <code>true</code> if the given offset is inside an inline context.
   * <code>false</code> otherwise.
   * @throws BadLocationException When the offset does not exists in the document content.
   * @throws AuthorOperationException If the operation failed.
   */
  boolean inInlineContext(int offset) throws BadLocationException, AuthorOperationException;
  
  /**
   * Add an Author listener to be notified about changes regarding the document 
   * and the document structure.
   * 
   * @param listener The {@link AuthorListener} to be added. 
   */
  void addAuthorListener(AuthorListener listener);
  
  /**
   * Remove an Author listener.
   * 
   * @param listener The {@link AuthorListener} to be removed. 
   */
  void removeAuthorListener(AuthorListener listener);
  
  /**
   * Evaluates an XPath expression.
   * This function returns the result of the given XPath expression as an array of {@link Object}.
   * Author DOM text nodes, DOM CDATA sections and DOM comment wrappers can be 
   * ignored for performance reasons.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the Author DOM Node wrappers in the document.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all the Author DOM Node wrappers in the document and having as last component
   * the total number of nodes.
   * 
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * @param ignoreTexts If <code>true</code> DOM text nodes will not be returned.
   * @param ignoreCData If <code>true</code> DOM CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> DOM comments will not be returned.
   * @param processChangeMarkers If <code>false</code> the change markers (inserts/deletes/comments) will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * If <code>true</code> the XPath will be applied over the document as if the change markers are applied.
   * (All changes processed to processing instructions like when the XML document gets saved on disk).
   * @return An array of objects representing the XPath result.
   *         It does not return a <code>null</code> array. If the XPath evaluation fails it will return
   *         an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  Object[] evaluateXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments, boolean processChangeMarkers) 
    throws AuthorOperationException;
  
  /**
   * Evaluates an XPath expression.
   * This function returns the result of the given XPath expression as an array of {@link Object}.
   * Author DOM text nodes, DOM CDATA sections and DOM comment wrappers can be 
   * ignored for performance reasons.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the Author DOM Node wrappers in the document.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all the Author DOM Node wrappers in the document and having as last component
   * the total number of nodes.
   * 
   * If change tracking (insert/remove/comment) markers exist in the document they will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * 
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * @param ignoreTexts If <code>true</code> DOM text nodes will not be returned.
   * @param ignoreCData If <code>true</code> DOM CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> DOM comments will not be returned.
   * @return An array of objects representing the XPath result.
   *         It does not return a <code>null</code> array. If the XPath evaluation fails it will return
   *         an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  Object[] evaluateXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Finds the author nodes selected by the given XPath expression.
   * The result of this function is an array of {@link AuthorNode} selected 
   * by the given XPath expression.
   * Author text nodes, Author CDATA section nodes and Author comment nodes 
   * can be ignored for performance reasons.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the AuthorNode's in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   *
   * If change tracking (insert/remove/comment) markers exist in the document they will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * 
   * @param xpathExpression The XPath expression.
   * @param ignoreTexts If <code>true</code> Author text nodes will not be returned.
   * @param ignoreCData If <code>true</code> Author CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> Author comments will not be returned.
   * @param processChangeMarkers If <code>false</code> the change markers (inserts/deletes/comments) will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * If <code>true</code> the XPath will be applied over the document as if the change markers are applied.
   * (All changes processed to processing instructions like when the XML document gets saved on disk).
   * 
   * @return The Author nodes selected by the XPath expression.
   *         It does not return a <code>null</code> array of nodes.
   *         If the evaluation of the XPath expression fails it will return an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  AuthorNode[] findNodesByXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments, boolean processChangeMarkers) 
    throws AuthorOperationException;
  
  /**
   * Finds the author nodes selected by the given XPath expression.
   * The result of this function is an array of {@link AuthorNode} selected 
   * by the given XPath expression.
   * Author text nodes, Author CDATA section nodes and Author comment nodes 
   * can be ignored for performance reasons.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the AuthorNode's in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   * 
   * If change tracking (insert/remove/comment) markers exist in the document the XPath will be applied over the document as if the change tracking is applied 
   * (All changes processed to processing instructions like when the XML document gets saved on disk).
   * 
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * @param ignoreTexts If <code>true</code> Author text nodes will not be returned.
   * @param ignoreCData If <code>true</code> Author CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> Author comments will not be returned.
   * @return The Author nodes selected by the XPath expression.
   *         It does not return a <code>null</code> array of nodes.
   *         If the evaluation of the XPath expression fails it will return an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  AuthorNode[] findNodesByXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Compute the document offset defined by the XPath location and relative position.
   * 
   * @param xpathLocation The XPath defining a node in document.
   * @param relativePosition  The relative position to the node. 
   * One of the following: {@link AuthorConstants#POSITION_BEFORE}, 
   * {@link AuthorConstants#POSITION_INSIDE_FIRST}, {@link AuthorConstants#POSITION_INSIDE_LAST} or
   * {@link AuthorConstants#POSITION_AFTER}
   * @return  The offset in document.
   * @throws AuthorOperationException If it fails.
   */
  public int getXPathLocationOffset(String xpathLocation, String relativePosition)
    throws AuthorOperationException;
  
  /**
   * Insert multiple elements at the given offsets.
   * <br>
   * Note: <i>The offsets and elements must be in document order.</i>
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges. 
   * 
   * @param parentElement The parent element that contains all the new inserted 
   * elements. 
   * @param elementNames The element names to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted.
   * @param namespace The namespace of the new inserted elements.
   */
  public void insertMultipleElements(AuthorElement parentElement, String[] elementNames,
      int[] offsets, String namespace);
  
  /**
   * Deletes the given intervals.
   * <br>
   * Note: <i>The offsets must be in document order and the intervals must not 
   * intersect with each other.</i>
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.
   * 
   * @param parentElement The element that contains all the deleted intervals.
   * @param startOffsets The start offset for each interval.
   * Must be in document order.
   * @param endOffsets The end offset for each interval.
   * Must be in document order.
   */
  public void multipleDelete(
      AuthorElement parentElement, 
      int[] startOffsets, 
      int[] endOffsets);

  /**
   * Set a new internal document type to the Author content.
   * 
   * This is a good method to add new entities (regular or unparsed) to the internal document type of the document.
   * 
   * WARNING: if these modifications affect regular entities already inserted and expanded,
   * they will not be re-parsed and their old content will remain rendered as such. 
   * 
   * @param docType The document type information.
   */
  void setDoctype(AuthorDocumentType docType);
  
  /**
   * Returns information about the internal associated document type.
   * 
   * @return The internal associated document type information.
   *         If the document does not have an internal Doctype section 
   *         the method will return <code>null</code>.
   */
  AuthorDocumentType getDoctype();
  
  /**
   * Find the common ancestor node of the two offsets.
   * <br/>
   * The author content contains the entire XML document text and special marker characters.
   * Each author node points in the content to the start and end marker characters which are used to  
   * delimit it's range.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * The image represents part of the document content and red markers represent special control
   * characters which represent the node ranges.  
   * 
   * @param doc The author document.
   * @param startOffset The start offset.
   * @param endOffset The end offset.
   * @return The common ancestor. Can be the document but it cannot be <code>null</code>.
   * @throws BadLocationException
   */
  AuthorNode getCommonParentNode(AuthorDocument doc, int startOffset, int endOffset) throws BadLocationException;
  
  /**
   * Returns the edited author document.
   * 
   * @return The author document. The document cannot be <code>null</code>.
   */
  AuthorDocument getAuthorDocumentNode();
  
  /**
   * Sets the {@link AuthorDocumentFilter} to be used for altering the document edits.
   * 
   * @param authorDocumentFilter The {@link AuthorDocumentFilter} to be used.
   */
  void setDocumentFilter(AuthorDocumentFilter authorDocumentFilter);
  
  /**
   * The content represents the entire text content of the Author page + additional markers/sentinels 
   * at offsets which are pointed to by the AuthorNodes.
   * Each AuthorNode points to specific start and end character markers in the content.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   *  
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * 
   * Retrieves a portion of the content into the specified {@link Segment}. 
   *
   * @param where The starting position >= 0, where + len <= length()
   * @param len The number of characters to be retrieved >= 0
   * @param chars The {@link Segment} object to return the characters int.o
   * @exception BadLocationException If the specified position or length are invalid.
   */
  public void getChars(int where, int len, Segment chars) throws BadLocationException;
  
  /**
   * Retrieves the content between the given start and end offset, excluding the 
   * content of the invisible nodes (that have display none style property), the 
   * content deleted with track changes, the sentinels of inline elements and the
   * content of filtered nodes. <br/>
   * The filtered nodes are the nodes for which
   * {@link AuthorNodesFilter#shouldFilterNode(AuthorNode)} returns <code>true</code>.
   * <br/> <br/>
   * The content represents the entire text content of the Author page + additional markers/sentinels 
   * at offsets which are pointed to by the AuthorNodes.
   * Each AuthorNode points to specific start and end character markers in the content.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   * <br/>
   * <img src="AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * 
   * Retrieves the content from start to end offsets,  
   * 
   * @param start The starting position >= 0.
   * @param end The end position >= 0, inclusive
   * @param nodesFilter Provides information about the Author nodes that should be filtered.
   * @return The char sequence representing the filtered Author content.
   * 
   * @since 12.1
   */
  public AuthorFilteredContent getFilteredContent(int start, int end, AuthorNodesFilter nodesFilter);
  
  /**
   * @return The schema manager associated with this document. Null value is returned if there is no schema associated.
   */
  public AuthorSchemaManager getAuthorSchemaManager();

  /**
   * Insert an XML fragment relative to the node identified by the <code>xpathLocation</code> 
   * and according with the <code>relativePosition</code>.
   * Note: if the <code>xpathLocation</code> is not specified then the XML fragment 
   * will be inserted at caret position and the <code>relativePosition<code> will be ignored. 
   * <p>
   * <p>For more details about schema aware solutions see comments from {@link #insertXMLFragmentSchemaAware(String, int)} method.</p>
   * 
   * @param xmlFragment The XML fragment.
   * @param xpathLocation The XPath location.
   * @param relativePosition The position relative to the node identified by the XPath location. 
   * Can be one of the constants: {@link AuthorConstants#POSITION_BEFORE}, {@link AuthorConstants#POSITION_AFTER}, 
   * {@link AuthorConstants#POSITION_INSIDE_FIRST} or {@link AuthorConstants#POSITION_INSIDE_LAST}.
   * @throws AuthorOperationException If the fragment could not be inserted.
   * 
   * @return The result of the schema aware insertion. 
   *   
   * @see #insertXMLFragmentSchemaAware(String, int)
   */
  SchemaAwareHandlerResult insertXMLFragmentSchemaAware(String xmlFragment, String xpathLocation,
      String relativePosition) throws AuthorOperationException;

  /**
   * Test if a node is editable or not. A node is not editable for one of the following cases:
   * <ul>
   *   <li>the CSS property 'editable' is to 'false';</li>
   *   <li>the node is entirely included into a DELETED change marker.</li>
   * <ul> 
   * @param node The node to test if is editable.
   * @return True if the node is editable, false otherwise.
   */
  boolean isEditable(AuthorNode node);

  /**
   * Rename an Author Element, set another qualified name to it.
   * 
   * @param contextNode The element to rename.
   * @param newName The new qualified name to set to it.
   * 
   * @since 12.1
   */
  void renameElement(AuthorElement contextNode, String newName);

  /**
   * Get an iterator over the text content between two offsets.
   * 
   * @param startOffset Start offset, 0 based, inclusive.
   * @param endOffset End offset, 0 based, inclusive.
   * @return The text content iterator
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  TextContentIterator getTextContentIterator(int startOffset, int endOffset);
  
  /**
   * Create a flexible position in the Author Content. The position is updated automatically when modifications occur before it. 
   * It behaves exactly like a {@link javax.swing.text.Position} added to a swing {@link Document}.
   * 
   * @param offset The offset where to create the position
   * @return The created position.
   * @throws BadLocationException 
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  Position createPositionInContent(int offset) throws BadLocationException;
  
  /**
   * Add a processor which can analyze and modify {@link AuthorDocumentFragment} objects before they are inserted in the Author.
   * The processor specified in the {@link ExtensionsBundle} will have maximum priority. 
   * 
   * @param clipboardFragmentProcessor a processor which can analyze and modify {@link AuthorDocumentFragment} objects before they are inserted in the Author.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  void addClipboardFragmentProcessor(ClipboardFragmentProcessor clipboardFragmentProcessor);
  
  /**
   * Remove a processor which can analyze and modify {@link AuthorDocumentFragment} objects before they are inserted in the Author.
   * 
   * @param clipboardFragmentProcessor a processor which can analyze and modify {@link AuthorDocumentFragment} objects before they are inserted in the Author.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  void removeClipboardFragmentProcessor(ClipboardFragmentProcessor clipboardFragmentProcessor);
  
  /**
   * Add a processor which is asked to automatically generate unique IDs after content has been inserted in the Author.
   * The processor can also specify which attributes can be copied on split.
   * 
   * The {@link UniqueAttributesRecognizer} specified in the {@link ExtensionsBundle} will have maximum priority. 
   * 
   * @param uniqueAttributesProcessor a processor which is asked to automatically generate unique IDs after content has been inserted in the Author.
   * The processor can also specify which attributes can be copied on split.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  void addUniqueAttributesProcessor(UniqueAttributesProcessor uniqueAttributesProcessor);
  
  /**
   * Remove a processor which is asked to automatically generate unique IDs after content has been inserted in the Author.
   * The processor can also specify which attributes can be copied on split.
   * 
   * The {@link UniqueAttributesRecognizer} specified in the {@link ExtensionsBundle} will have maximum priority. 
   * 
   * @param uniqueAttributesProcessor a processor which is asked to automatically generate unique IDs after content has been inserted in the Author.
   * The processor can also specify which attributes can be copied on split.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>
   */
  void removeUniqueAttributesProcessor(UniqueAttributesProcessor uniqueAttributesProcessor);

  /**
   * Finds the author nodes selected by the given XPath expression.
   * The result of this function is an array of {@link AuthorNode} selected 
   * by the given XPath expression.
   * Author text nodes, Author CDATA section nodes and Author comment nodes 
   * can be ignored for performance reasons.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the AuthorNode's in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   *
   * If change tracking (insert/remove/comment) markers exist in the document they will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * 
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the current caret position.
   * @param contextNode The node in the context of which the relative XPath Expressions will computed. 
   * If <code>null</code> the context node will be the node at the current caret position. 
   * @param ignoreTexts If <code>true</code> Author text nodes will not be returned.
   * @param ignoreCData If <code>true</code> Author CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> Author comments will not be returned.
   * @param processChangeMarkers If <code>false</code> the change markers (inserts/deletes/comments) will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * If <code>true</code> the XPath will be applied over the document as if the change markers are applied.
   * (All changes processed to processing instructions like when the XML document gets saved on disk).
   * 
   * @return The Author nodes selected by the XPath expression.
   *         It does not return a <code>null</code> array of nodes.
   *         If the evaluation of the XPath expression fails it will return an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   * 
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p> 
   */
  AuthorNode[] findNodesByXPath(String xpathExpression, AuthorNode contextNode, boolean ignoreTexts, 
      boolean ignoreCData, boolean ignoreComments, boolean processChangeMarkers) 
    throws AuthorOperationException;

  /**
   * Evaluates an XPath expression.
   * This function returns the result of the given XPath expression as an array of {@link Object}.
   * Author DOM text nodes, DOM CDATA sections and DOM comment wrappers can be 
   * ignored for performance reasons.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the Author DOM Node wrappers in the document.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all the Author DOM Node wrappers in the document and having as last component
   * the total number of nodes.
   * 
   * @param xpathExpression The XPath expression. If the XPath expression is relative, it will be computed in the context of the context node.
   * @param contextNode The node in the context of which the relative XPath Expressions will computed. 
   * If <code>null</code> the context node will be the node at the current caret position. 
   * @param ignoreTexts If <code>true</code> DOM text nodes will not be returned.
   * @param ignoreCData If <code>true</code> DOM CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> DOM comments will not be returned.
   * @param processChangeMarkers If <code>false</code> the change markers (inserts/deletes/comments) will be ignored 
   * and the XPath will return results as if the insert changes are accepted, the delete changes are rejected and the comment changes are ignored.
   * If <code>true</code> the XPath will be applied over the document as if the change markers are applied.
   * (All changes processed to processing instructions like when the XML document gets saved on disk).
   * @return An array of objects representing the XPath result.
   *         It does not return a <code>null</code> array. If the XPath evaluation fails it will return
   *         an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  Object[] evaluateXPath(String xpathExpression, AuthorNode contextNode, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments, boolean processChangeMarkers) 
    throws AuthorOperationException;
}