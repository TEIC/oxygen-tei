/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

/**
 * Mouse event received by the {@link AuthorMouseListener}.
 */
public class AuthorMouseEvent extends AuthorInputEvent {
  /**
   * Mouse pressed event type.
   * The value is 1.
   */
  public static final int STATE_PRESSED = 1;
  
  /**
   * Mouse released event type.
   * The value is 2.
   */
  public static final int STATE_RELEASED = 2;
  
  /**
   * Mouse clicked event type.
   * The value is 3.
   */
  public static final int STATE_CLICKED = 3;
  
  /**
   * Mouse moved event type.
   * The value is 4.
   */
  public static final int STATE_MOVED = 4;
  
  /**
   * Mouse dragged event type.
   * The value is 5.
   */
  public static final int STATE_DRAGGED = 5;
  
  /**
   * Indicates mouse button #1.
   * The value is 1.
   */ 
  public static final int BUTTON1 = 1;

  /**
   * Indicates mouse button #2.
   * The value is 2.
   */ 
  public static final int BUTTON2 = 2;

  /**
   * Indicates mouse button #3.
   * The value is 3.
   */ 
  public static final int BUTTON3 = 3;
  
  /**
   * Indicates no mouse button.
   * The value is 0. 
   */ 
  public static final int NOBUTTON = 0;
  
  /**
   * The mouse event's x coordinate.
   * The x value is relative to the author page.
   */
  public final int X;

  /**
   * The mouse event's y coordinate.
   * The y value is relative to the author page.
   */
  public final int Y;
  
  /**
   * <code>true</code> if this event is a pop-up trigger.
   */
  public final boolean popupTrigger;

  /**
   * Click count.
   */
  public final int clickCount;

  /**
   * Indicates which, if any, of the mouse buttons has changed its state.
   *
   * The only legal values are the following constants:
   * <code>NOBUTTON</code>,
   * <code>BUTTON1</code>,
   * <code>BUTTON2</code> or
   * <code>BUTTON3</code>.
   */
  public final int button;

  /**
   * One of the constants {@link #STATE_PRESSED}, {@link #STATE_RELEASED},
   * {@link #STATE_CLICKED}, {@link #STATE_MOVED} or {@link #STATE_DRAGGED}.
   */
  public final int state;
  
  /**
   * Constructor for the author mouse event.
   * 
   * @param x The x coordinate of the mouse event.
   * @param y The y coordinate of the mouse event.
   * @param isPopupTrigger <code>true</code> if it is pop-up trigger.
   * @param state One of the constants {@link #STATE_PRESSED}, {@link #STATE_RELEASED},
   * {@link #STATE_CLICKED}, {@link #STATE_MOVED} or {@link #STATE_DRAGGED}.
   * @param modifiers Marks if CTRL, SHIFT, ALT, ALT GR, META were pressed.
   * @param clickCount Click count.
   */
  public AuthorMouseEvent(int x, int y, boolean isPopupTrigger,
      int state, int modifiers, int clickCount) {
    this(x, y, isPopupTrigger, state, modifiers, clickCount, NOBUTTON);
  }
  
  /**
   * Constructor for the author mouse event.
   * 
   * @param x The x coordinate of the mouse event.
   * @param y The y coordinate of the mouse event.
   * @param isPopupTrigger <code>true</code> if it is pop-up trigger.
   * @param state One of the constants {@link #STATE_PRESSED}, {@link #STATE_RELEASED},
   * {@link #STATE_CLICKED}, {@link #STATE_MOVED} or {@link #STATE_DRAGGED}.
   * @param modifiers Marks if CTRL, SHIFT, ALT, ALT GR, META were pressed.
   * @param clickCount Click count.
   * @param button One of the constants {@link #BUTTON1}, {@link #BUTTON2}, {@link #BUTTON3}, {@link #NOBUTTON}.
   */
  public AuthorMouseEvent(int x, int y, boolean isPopupTrigger,
      int state, int modifiers, int clickCount, int button) {
    super(modifiers);
    this.X = x;
    this.Y = y;
    this.popupTrigger = isPopupTrigger;
    this.state = state;
    this.clickCount = clickCount;
    this.button = button;
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    String str = "Author mouse event, type: " 
      + getStateDescription(state) 
      + ", x: " + X 
      + ", y: " + Y 
      + ", consumed: " + isConsumed()
      + ", modifiers: " + getModifiers(); 
    return str;
  }

  /**
   * @return String representation for mouse state.
   */
  protected String getStateDescription(int state) {
    String toRet = "unknown";
    switch (state) {
      case STATE_CLICKED:
        toRet = "clicked";
        break;
      case STATE_PRESSED:
        toRet = "pressed";
        break;
      case STATE_RELEASED:
        toRet = "released";
        break;
      case STATE_MOVED:
        toRet = "moved";
        break;
      case STATE_DRAGGED:
        toRet = "dragged";
        break;
    }
    return toRet;
  }
  
  /**
   * Returns the number of mouse clicks associated with this event.
   *
   * @return integer value for the number of clicks
   */
  public int getClickCount() {
    return clickCount;
  }

  /**
   * Returns which, if any, of the mouse buttons has changed state.
   *
   * @return one of the following constants:
   * <code>NOBUTTON</code>,
   * <code>BUTTON1</code>,
   * <code>BUTTON2</code> or
   * <code>BUTTON3</code>.
   */
  public int getButton() {
    return button;
  }

  /**
   * Returns whether or not this mouse event is the popup menu
   * trigger event for the platform.
   * <p><b>Note</b>: Popup menus are triggered differently
   * on different systems. Therefore, <code>isPopupTrigger</code>
   * should be checked in both <code>mousePressed</code>
   * and <code>mouseReleased</code>
   * for proper cross-platform functionality.
   *
   * @return boolean, true if this event is the popup menu trigger
   *         for this platform
   */
  public boolean isPopupTrigger() {
    return popupTrigger;
  }

  /**
   * Returns the horizontal x position of the event relative to the 
   * source component.
   *
   * @return x  an integer indicating horizontal position relative to
   *            the component
   */
  public int getX() {
    return X;
  }

  /**
   * Returns the vertical y position of the event relative to the
   * source component.
   *
   * @return y  an integer indicating vertical position relative to
   *            the component
   */
  public int getY() {
    return Y;
  }
  
  /**
   * Returns the state.
   * 
   *  @return one of the following constants:
   * <code>STATE_PRESSED</code>,
   * <code>STATE_RELEASED</code>,
   * <code>STATE_CLICKED</code>
   * <code>STATE_DRAGGED</code> or
   * <code>STATE_MOVED</code>.
   */
  public int getState() {
    return state;
  }
}