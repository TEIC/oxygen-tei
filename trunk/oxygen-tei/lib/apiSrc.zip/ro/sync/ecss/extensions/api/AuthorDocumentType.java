/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.util.Equaler;
import ro.sync.xml.DocumentTypeUtil;

/**
 * Author structure representing DOCTYPE information as present in the Author document.
 */
public class AuthorDocumentType implements Cloneable {

  /**
   * The system ID of the DOCTYPE
   */
  private final String systemID;
  
  /**
   * The public ID of the DOCTYPE
   */
  private final String publicID;
  
  /**
   * The DOCTYPE name (the XML root name).
   */
  private final String name;
  
  /**
   * The entire content of the DOCTYPE header present in the XML document.
   */
  private final String doctypeContent;

  /**
   * Constructor.
   * 
   * @param name  The DOCTYPE name.
   * @param systemID The systemID.
   * @param publicID Public id.
   * @param doctypeContent The DOCTYPE content
   * 
   * Example for creating a Docbook AuthorDocumentType:
   * <pre>
   * AuthorDocumentType doctype = new AuthorDocumentType(
   *     "article", 
   *     "http://www.docbook.org/xml/4.4/docbookx.dtd", 
   *     "-//OASIS//DTD DocBook XML V4.4//EN",
   *     "&lt;!DOCTYPE article PUBLIC \"-//OASIS//DTD DocBook XML V4.4//EN\"\n" + 
   *     "             \"http://www.docbook.org/xml/4.4/docbookx.dtd\"[\n" + 
   *     " &lt;!ENTITY ent 'this is an entity'>\n" + 
   *     "]>");
   * </pre>
   */
  public AuthorDocumentType(String name, String systemID, String publicID, String doctypeContent) {
    this.name = name;
    this.systemID = systemID;
    this.publicID = publicID;
    this.doctypeContent = doctypeContent;
  }
  
  /**
   * @return The name of DTD; i.e., the name immediately following the 
   * <code>DOCTYPE</code> keyword.
   */
  public String getName() {
    return name;
  }
  
  /**
   * @return The public identifier of the external subset.
   */
  public String getPublicId() {
    return publicID;
  }

  /**
   * @return The system identifier of the external subset. This may be an absolute 
   * URI or not.
   */
  public String getSystemId() {
    return systemID;
  }

  /**
   * @return The whole content of the DOCTYPE for serialization
   * 
   * Example:
   * <pre>
   * &lt;!DOCTYPE article PUBLIC "-//OASIS//DTD DocBook XML V4.4//EN"
   *                      "http://www.docbook.org/xml/4.4/docbookx.dtd"[
   *   &lt;!ENTITY ent 'this is an entity'>
   * ]>
   * </pre>
   */
  public String getContent() {
    return doctypeContent;
  }
  
  /**
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    boolean equals = false;
    if (obj instanceof AuthorDocumentType) {
      AuthorDocumentType other = (AuthorDocumentType) obj;
      equals = Equaler.verifyEquals(name, other.name)
      && Equaler.verifyEquals(systemID, other.systemID) 
      && Equaler.verifyEquals(publicID, other.publicID)
      && Equaler.verifyEquals(doctypeContent, other.doctypeContent);
    }
    return equals;
  }
  
  /**
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    int hashCode = serializeDoctype().hashCode();
    return hashCode;
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "Doctype Root: " + name + " Public ID: " + publicID + " System ID: " + systemID + 
    "\nContent: " + doctypeContent;
  }
  
  /**
   * Serialize the doctype
   * @return The serialized doctype
   */
  public String serializeDoctype() {
    StringBuffer contentBuffer = new StringBuffer();
    // Serialize the DOCTYPE        
    if (doctypeContent != null) {
      contentBuffer.append(doctypeContent);
    } else {
      if (name != null) {
        contentBuffer.append(DocumentTypeUtil.extractDoctypeContentFromDoctypeInfo(
            name, publicID, systemID, null));
      }
    }
    return contentBuffer.toString();
  }
  
  /**
   * Clones this doctype.
   * @see java.lang.Object#clone()
   */
  @Override
  public AuthorDocumentType clone() {
    try {
      return (AuthorDocumentType) super.clone();// new AuthorDocumentType(name, systemID, publicID, doctypeContent);
    } catch (CloneNotSupportedException e) {
      return null;
    }
  }
}