/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.content;

import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Information about the node which contains the offset. 
 * If the offset is on a marker character the returned result will also contain the node which contains the range indicated by the marker. 
 * <br/>
 * <img src="OffsetInformation.gif"/> 
 * <br/>
 * The author content contains the entire XML document text and special marker characters.
 * Each author node points in the content to the start and end marker characters which are used to  
 * delimit it's range.
 * The start and end offsets pointed to by the AuthorNode can be retrieved using the
 * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
 * The image represents part of the document content and red markers represent special control
 * characters which represent the node ranges.   
 * 
 * @since 12.2
 */
public interface OffsetInformation {
  /**
   * The offset is in character content.
   */
  int IN_CONTENT = 0;

  /**
   * The offset is on the marker representing the start range of a node.
   */
  int ON_START_MARKER = 1;

  /**
   * The offset is on the marker representing the end range of a node.
   */
  int ON_END_MARKER = 2;

  /**
   * If the offset is on a marker character this method returns the node which contains the marker.
   * 
   * @return If the offset is on a marker character this method returns the node which contains the marker.
   */
  AuthorNode getNodeForMarkerOffset();
  
  /**
   * Returns the parent node for the given offset. Never <code>null</code>.
   * 
   * @return the parent node for the given offset. Never <code>null</code>.
   */
  AuthorNode getNodeForOffset();
  
  /**
   * Get the type of position the offset has.
   * 
   * It returns one of the constants: {@link #IN_CONTENT} or {@link #ON_START_MARKER} or {@link #ON_END_MARKER}
   * 
   * @return the type of position for the offset.
   */
  int getPositionType();  
}