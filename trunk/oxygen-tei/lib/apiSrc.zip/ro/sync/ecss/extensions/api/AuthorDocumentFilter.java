/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * <code>AuthorDocumentFilter</code>, is a filter for the methods which modify the
 * <code>AuthorDocument</code>. When the <code>AuthorDocument</code>
 * is modified through the methods from the <code>AuthorDocumentController</code>, 
 * the appropriate method invocation is forwarded to the <code>AuthorDocumentFilter</code>. 
 * The default implementation allows the modification to
 * occur. Subclasses can filter the modifications by conditionally invoking
 * methods on the superclass, or invoking the necessary methods on
 * the passed in <code>AuthorDocumentFilterBypass</code>. 
 * <p><b><u>Warning:</u> Subclasses should NOT call back
 * into the AuthorDocumentController for modifications in the document
 * instead call into the superclass or the <code>AuthorDocumentFilterBypass</code>!</b>
 * <p>
 * When methods are invoked on the <code>AuthorDocumentFilter</code>, the 
 * <code>AuthorDocumentFilter</code> may callback into the
 * <code>AuthorDocumentFilterBypass</code> multiple times, or for different regions, but
 * it should not callback into the <code>AuthorDocumentFilterBypass</code> after returning
 * from the initially called method. 
 */
public class AuthorDocumentFilter {
  /**
   * Invoked before inserting the specified text at the given offset.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param offset  The offset where the text will be inserted. 0 based.
   * @param toInsert  The text to be inserted.
   */
  public void insertText(AuthorDocumentFilterBypass filterBypass, int offset, String toInsert) {
    filterBypass.insertText(offset, toInsert);
  }

  /**
   * Invoked before inserting an {@link AuthorDocumentFragment} at the specified offset.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param offset The offset where the fragment will be inserted. 0 based.
   * @param frag The {@link AuthorDocumentFragment} to be inserted.
   */
  public void insertFragment(AuthorDocumentFilterBypass filterBypass, int offset,
      AuthorDocumentFragment frag) {
    filterBypass.insertFragment(offset, frag);
  }
  
  /**
   * Invoked before inserting a simple node into the document.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param offset The offset where the node should be inserted. 0 based.
   * @param node The {@link AuthorNode} to be inserted.
   * @return <code>true</code> if the insert node operation succeeded.
   */
  public boolean insertNode(AuthorDocumentFilterBypass filterBypass, int offset,
      AuthorNode node) {
    return filterBypass.insertNode(offset, node);
  }

  /**
   * Invoked before inserting multiple elements at the given offsets.
   * <br>
   * Note: <i>The offsets and elements are in document order and this rule must also be followed
   * by the filter processing.</i>
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param parentElement The parent element that contains all the new inserted 
   * elements. 
   * @param elementNames The element names to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted. 0 based.
   * @param namespace The namespace of the new inserted elements.
   */
  public void insertMultipleElements(AuthorDocumentFilterBypass filterBypass,
      AuthorElement parentElement, String[] elementNames, int[] offsets, String namespace) {
    filterBypass.insertMultipleElements(parentElement, elementNames, offsets, namespace);
  }

  /**
   * Invoked before deleting the fragment between the specified offsets from the document.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param startOffset Start offset of the fragment, 0 based and inclusive.
   * @param endOffset End offset of the fragment, 0 based and inclusive.
   * @param withBackspace <code>true</code> if <code>BACKSPACE</code> key was used for deleting the fragment. 
   * @return true If the delete operation succeeded.
   */
  public boolean delete(AuthorDocumentFilterBypass filterBypass, int startOffset, int endOffset,
      boolean withBackspace) {
    return filterBypass.delete(startOffset, endOffset, withBackspace);
  }

  /**
   * Invoked before deleting the specified node from the document.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param node The {@link AuthorNode} to delete.
   * @return <code>true</code> if the delete node operation was successful. 
   */
  public boolean deleteNode(AuthorDocumentFilterBypass filterBypass, AuthorNode node) {
    return filterBypass.deleteNode(node);
  }

  /**
   * Invoked before deleting the given intervals from the document.
   * <br>
   * Note: <i>The offsets must be in document order and the intervals must not 
   * intersect with each other. This rule must also be followed by the filter processing.</i>
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param parentElement The element that contains all the deleted intervals.
   * @param startOffsets The start offset for each interval.
   * Must be in document order. 0 based and inclusive.
   * @param endOffsets The end offset for each interval.
   * Must be in document order. 0 based and inclusive.
   */
  public void multipleDelete(AuthorDocumentFilterBypass filterBypass, AuthorElement parentElement,
      int[] startOffsets, int[] endOffsets) {
    filterBypass.multipleDelete(parentElement, startOffsets, endOffsets);
  }

  /**
   * Invoked before renaming the given element.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param element The {@link AuthorElement} that is renamed.
   * @param newName The new name for the element.
   * @param infoProvider Information provider used for internal processing. It must NOT be altered inside this 
   * {@link AuthorDocumentFilter} method.
   */
  public void renameElement(AuthorDocumentFilterBypass filterBypass,
      AuthorElement element, String newName, Object infoProvider) {
    filterBypass.renameElement(element, newName, infoProvider);
  }
  
  /**
   * Invoked before setting the value of an attribute in the specified element.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary. 
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param attributeName Name of the attribute being changed.
   * @param value New {@link AttrValue} for the attribute. If <code>null</code>, the attribute is 
   * removed from the element.
   * @param element The {@link AuthorElement} whose attribute we are editing. 
   */
  public void setAttribute(AuthorDocumentFilterBypass filterBypass, String attributeName,
      AttrValue value, AuthorElement element) {
    filterBypass.setAttribute(attributeName, value, element);
  }

  /**
   * Invoked before removing an attribute from the specified element.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param attributeName Name of the attribute to remove.
   * @param element The {@link AuthorElement} whose attribute will be removed.
   */
  public void removeAttribute(AuthorDocumentFilterBypass filterBypass, String attributeName,
      AuthorElement element) {
    filterBypass.removeAttribute(attributeName, element);
  }

  /**
   * Invoked before splitting the specified node into two similar nodes.
   * The node to split is the first ancestor block level node containing the
   * <code>splitOffset</code>.
   * The attributes of the splitted node will also be copied excepting the 
   * unique ones. The unique attributes are identified by the {@link UniqueAttributesRecognizer}.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param toSplit The {@link AuthorNode} to split.
   * @param splitOffset The split offset. The given offset is greater or equal 
   * to 1 and less than the current document length.
   * @return <code>true</code> if the node was split.
   */
  public boolean split(AuthorDocumentFilterBypass filterBypass, AuthorNode toSplit,
      int splitOffset) {
    return filterBypass.split(toSplit, splitOffset);
  }

  /**
   * Invoked before surrounding the fragment between the specified offset with the specified node.
   * The fragment between the start and end offsets will become the node actual content.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param node The {@link AuthorNode} that will surround the fragment.
   * @param startOffset Start offset of the surrounded fragment. 0 based and inclusive.
   * @param endOffset End offset of the surrounded fragment. 0 based and inclusive.
   * @param leftToRight <code>true</code> if after the operation the selection 
   * in the author page is done from the left to the right.
   */
  public void surroundWithNode(AuthorDocumentFilterBypass filterBypass, AuthorNode node,
      int startOffset, int endOffset, boolean leftToRight) {
    filterBypass.surroundWithNode(node, startOffset, endOffset, leftToRight);    
  }

  /**
   * Invoked before surrounding the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the content between start and end offset could not be surrounded.
   */
  public void surroundInFragment(AuthorDocumentFilterBypass filterBypass, String xmlFragment,
      int startOffset, int endOffset) throws AuthorOperationException {
    filterBypass.surroundInFragment(xmlFragment, startOffset, endOffset);
  }
  
  /**
   * Invoked before surrounding the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException 
   * 
   * @since 12.1
   */
  public void surroundInFragment(AuthorDocumentFilterBypass filterBypass, AuthorDocumentFragment xmlFragment,
      int startOffset, int endOffset) throws AuthorOperationException {
    filterBypass.surroundInFragment(xmlFragment, startOffset, endOffset);
  }

  /**
   * Invoked before surrounding the content between the given offsets with plain text fragments(without XML parsing). 
   * The method inserts the <code>header</code> at <code>startOffset</code> and 
   * the <code>footer</code> at <code>endOffset</code>.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   * 
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param header The header to be inserted before the surrounded text.
   * @param footer The footer to be inserted after the surrounded text.
   * @param startOffset The start offset of the text to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the text to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the operation failed.
   */
  public void surroundInText(AuthorDocumentFilterBypass filterBypass, String header, String footer,
      int startOffset, int endOffset) throws AuthorOperationException {
    filterBypass.surroundInText(header, footer, startOffset, endOffset);
  }

  /**
   * Invoked before setting a new internal document type to the Author content.
   * <p>Subclasses that want to conditionally modify the default processing
   * should override this and only call super implementation as
   * necessary, or call directly into the {@link AuthorDocumentFilterBypass} as
   * necessary.
   *  
   * @param filterBypass The document filter bypass used for executing operations directly,
   * without additional filtering.
   * @param docType The document type information to set.
   */
  public void setDoctype(AuthorDocumentFilterBypass filterBypass, AuthorDocumentType docType) {
    filterBypass.setDoctype(docType);
  }
}