/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.List;

import javax.swing.text.BadLocationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.sf.saxon.lib.ExtensionFunctionDefinition;

import org.apache.log4j.Logger;

import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.exml.workspace.api.util.XMLUtilAccess;
import ro.sync.util.URLUtil;
import ro.sync.util.xslt.URLGetPathFunctionCallDefinition;
import ro.sync.util.xslt.URLNewFunctionCallDefinition;
import ro.sync.util.xslt.URLUtilCopyURLFunctionCallDefinition;
import ro.sync.util.xslt.URLUtilUncorrectFunctionCallDefinition;
import ro.sync.util.xslt.UUIDHashCodeFunctionCallDefinition;
import ro.sync.util.xslt.UUIDRandomUUIDFunctionCallDefinition;

/**
 * This class is notified when URLs are dropped or pasted to an Author Editor page.
 * 
 * @since 12
 */
public abstract class AuthorExternalObjectInsertionHandler implements ExternalObjectInsertionSources{

  /**
   * Logger for logging. 
   */
  private static Logger logger = Logger.getLogger(AuthorExternalObjectInsertionHandler.class.getName());
  
  /**
   * Test stylesheet content.
   */
  public static final String TEST_STYLESHEET_CONTENT = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
  "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"2.0\"\n" + 
  "    xmlns:xhtml=\"http://www.w3.org/1999/xhtml\" exclude-result-prefixes=\"#all\"\n" + 
  "    xpath-default-namespace=\"http://www.w3.org/1999/xhtml\">\n" + 
  "    <xsl:output omit-xml-declaration=\"yes\"/>\n" +
  "    <xsl:template match=\"style\"/>\n" +
  "    <xsl:template match=\"script\"/>\n" +
  "    <xsl:template match=\"head\"/>\n" + 
  "    <xsl:template match=\"*\">\n" +
  "        <xsl:text> </xsl:text>\n" + 
  "        <xsl:apply-templates select=\"node()|text()\"/>\n" + 
  "        <xsl:text> </xsl:text>\n" + 
  "    </xsl:template>\n" + 
  "</xsl:stylesheet>";
  
  /**
   * The default stylesheet that is applied to the XHTML from clipboard if a 
   * custom stylesheet cannot be loaded from the framework. 
   */
  private static final String DEFAULT_STYLESHEET_CONTENT = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
  "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"2.0\"\n" + 
  "    xmlns:xhtml=\"http://www.w3.org/1999/xhtml\" exclude-result-prefixes=\"#all\"\n" + 
  "    xpath-default-namespace=\"http://www.w3.org/1999/xhtml\">\n" + 
  "    <xsl:output omit-xml-declaration=\"yes\"/>\n" +
  "    <xsl:template match=\"style\"/>\n" +
  "    <xsl:template match=\"script\"/>\n" +
  "    <xsl:template match=\"head\"/>\n" +
  "</xsl:stylesheet>";
  
  /**
   * Remove <tfoot> from XHTML before checking for consistency. 
   */
  private static final String REMOVE_TFOOT_STYLESHEET_CONTENT = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
  		"<xsl:stylesheet version=\"1.0\" \n" + 
  		"    xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" \n" + 
  		"    xmlns:xhtml=\"http://www.w3.org/1999/xhtml\">\n" + 
  		"    <xsl:output method=\"xml\" doctype-public=\"-//W3C//DTD XHTML 1.0 Transitional//EN\" \n" + 
  		"        doctype-system=\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"/>\n" + 
  		"    <xsl:template match=\"node() | @*\">\n" + 
  		"        <xsl:copy>\n" + 
  		"            <xsl:apply-templates select=\"node() | @*\"/>\n" + 
  		"        </xsl:copy>\n" + 
  		"    </xsl:template>\n" + 
  		"    <xsl:template match=\"xhtml:tfoot\"/>\n" + 
  		"</xsl:stylesheet>";

  /**
   * A list of URLs need to be inserted at the caret position, probably as links.
   * <br/>
   * The <code>source</code> of the insertion can be a <strong>paste</strong> event or a 
   * <strong>drag and drop</strong> event.
   * <br/>
   * This call back is received if {@link AuthorExternalObjectInsertionHandler#acceptURLs(AuthorAccess, List, int)}
   * returned <code>true</code> for the same <code>source</code> and <code>urls</code> list. 
   * <br/>
   * You can use it to link to those specific files/URLs.
   * 
   * @param authorAccess The author access
   * @param urls The list of URLs.
   * @param source The source of the URLs, one of the {@link AuthorExternalObjectInsertionHandler} constants.
   * @throws AuthorOperationException 
   */
  public void insertURLs(AuthorAccess authorAccess, List<URL> urls, int source) throws AuthorOperationException {
    //No implementation
  }

  /**
   * Confirm that the list of URLs is interesting to this handler.
   * <br/>
   * The <code>source</code> of the insertion can be a <strong>paste</strong> event or a 
   * <strong>drag and drop</strong> event. If the source is of <strong>drag and drop</strong> type and 
   * it is accepted, the caret will be moved to the drop position.
   * <br/>
   * By default accepts the URLs from external sources if the URLs are only images and
   * all URLs from paste events and drops from the Oxygen Project and DITA Maps Manager.
   * 
   * @param authorAccess The author access.
   * @param urls The list of URLs.
   * @param source The source of the URLs, one of the {@link AuthorExternalObjectInsertionHandler} constants.
   * @return <code>true</code> if the provided URLs are interesting.
   */
  public boolean acceptURLs(AuthorAccess authorAccess, List<URL> urls, int source) {
    if(acceptSource(authorAccess, source)
        //Dropped URLs contain only images
        || containOnlyImages(authorAccess, urls)) {
      return true;
    }
    return false;
  }

  /**
   * Confirm that the source of URLs is interesting to this handler.
   * <br/>
   * The <code>source</code> of the insertion can be a <strong>paste</strong> event or a 
   * <strong>drag and drop</strong> event. If the source is of <strong>drag and drop</strong> type and 
   * it is accepted, the caret will be moved to the drag position.
   * <br/>
   * By default accepts paste sources and drags from the Oxygen Project and DITA Maps Manager.
   * 
   * 
   * @param authorAccess The author access.
   * @param source The source of the URLs, one of the 
   * {@link AuthorExternalObjectInsertionHandler} constants (that represents a 
   * <strong>paste</strong> or a <strong>drag and drop</strong> event)
   * @return <code>true</code> if the insert URLs are interesting.
   */
  public boolean acceptSource(AuthorAccess authorAccess, int source) {
    if(
        //Drop from DITA Maps Manager
        source == DND_DITA_MAPS_MANAGER 
        //Drop from Project Tree
        || source == DND_PROJECT_TREE
        //Drop from DB Tree
        || source == DND_DB_TREE
        //Drop from Image Preview
        || source == DND_IMAGE_PREVIEW
        //Paste case
        || source == PASTE) {
      return true;
    }
    return false;
  }

  /**
   * Verify if the provided URLs are only images.
   * 
   * @param urlList The list of URLs
   * @return true if the URLs are only images.
   */
  protected static boolean containOnlyImages(AuthorAccess authorAccess, List<URL> urlList) {
    for (int i = 0; i < urlList.size(); i++) {
      URL dropped = urlList.get(i);
      if(!authorAccess.getUtilAccess().isSupportedImageURL(dropped)) {
        return false;
      }
    }
    return true;
  }
  
  /**
   * Logger for logging HTML content from clipboard.
   */
  private static class LoggerReader extends Reader {
    private Reader reader;
    
    private StringBuilder loggedContent = new StringBuilder();

    /**
     * Store the wrapped reader.
     */
    LoggerReader(Reader reader) {
      this.reader = reader;
    }
    
    /**
     * @see java.io.Reader#read(char[], int, int)
     */
    @Override
    public int read(char[] cbuf, int off, int len) throws IOException {
      int n = reader.read(cbuf, off, len);
      if (n > 0) {
        loggedContent.append(cbuf, off, n);
      }
      
      return n;
    }
    
    /**
     * @see java.io.Reader#close()
     */
    @Override
    public void close() throws IOException {
      logger.debug(loggedContent.toString());
      reader.close();
    }
  }
  
  
  /**
   * Insert an XHTML fragment
   * 
   * @param authorAccess The author access
   * @param xhtmlContentReader The XTHML content reader
   * @throws AuthorOperationException 
   * 
   * @since 12.1
   */
  public void insertXHTMLFragment(AuthorAccess authorAccess, Reader xhtmlContentReader) throws AuthorOperationException {
    StreamSource importerStylesheet = createImporterStylesheetSource(authorAccess);
    String initialXHTMLToPaste = null;
    if(importerStylesheet != null) {
      try {
        if (logger.isDebugEnabled()) {
          xhtmlContentReader = new LoggerReader(xhtmlContentReader);
        }
        
        //Read the content in a buffer
        initialXHTMLToPaste = readInitialXHTMLContent(xhtmlContentReader);
        
        //First transformation
        
        //Imported text
        String importedContent = applyAssociatedXSL(authorAccess, initialXHTMLToPaste, importerStylesheet);
        
        if(importedContent.length() > 0) {
          if(checkImportedXHTMLContentIsPreservedEntirely()) {
            String importedContentToCheck = importedContent;
            String initialXHTMLToCheck = initialXHTMLToPaste;
            
            //If we have table footers we have to filter them before performing the verification
            if(initialXHTMLToPaste.contains("tfoot")) {
              //Table footers must be skipped.
              initialXHTMLToCheck = simpleTransform(authorAccess, initialXHTMLToCheck, AuthorExternalObjectInsertionHandler.REMOVE_TFOOT_STYLESHEET_CONTENT);
              importedContentToCheck = applyAssociatedXSL(authorAccess, initialXHTMLToCheck, createImporterStylesheetSource(authorAccess));
            }
            
            //The words processed by the stylesheet.
            String contentProcessedByStylesheets = simpleTransform(
                authorAccess, "<root>" + importedContentToCheck + "</root>", AuthorExternalObjectInsertionHandler.TEST_STYLESHEET_CONTENT);

            //The initial words.
            String allWords = simpleTransform(authorAccess, initialXHTMLToCheck, AuthorExternalObjectInsertionHandler.TEST_STYLESHEET_CONTENT);
            
            if(testDataIsPreserved(contentProcessedByStylesheets, allWords)) {
              //All right, the stylesheet did not lose any data
              //Just paste it
              authorAccess.getDocumentController().insertXMLFragmentSchemaAware(importedContent, authorAccess.getEditorAccess().getCaretOffset(), true);
            } else {
              logger.warn("Initial XHTML to paste: |" + initialXHTMLToPaste + "|");
              //We have a problem, the applied XSLs have lost data...
              //Use the default transformer to extract only words.
              String onlyWords = simpleTransform(authorAccess, initialXHTMLToPaste, AuthorExternalObjectInsertionHandler.DEFAULT_STYLESHEET_CONTENT);
              authorAccess.getDocumentController().insertXMLFragmentSchemaAware(onlyWords, authorAccess.getEditorAccess().getCaretOffset(), true);
            }
          } else {
            //Just paste it
            authorAccess.getDocumentController().insertXMLFragmentSchemaAware(importedContent, authorAccess.getEditorAccess().getCaretOffset(), true);
          }
        }
      } catch(AuthorOperationStoppedByUserException ex) {
        //EXM-19122 Ignore canceled dialog.
      } catch (Exception e) {
        if (logger.isDebugEnabled()) {
          logger.debug(e, e);
        }
        authorAccess.getWorkspaceAccess().showErrorMessage(e.getMessage());
      }
    }
  }
  
  private static String simpleTransform(AuthorAccess authorAccess, String xml, String xsl) throws TransformerException, IOException {
    Transformer skipTFootTransformer = authorAccess.getXMLUtilAccess().createXSLTTransformer(
        new StreamSource(new StringReader(xsl)), new URL[0], XMLUtilAccess.TRANSFORMER_SAXON_HOME_EDITION, false);
    StringWriter sw = new StringWriter();
    skipTFootTransformer.transform(new StreamSource(new StringReader(xml)), new StreamResult(sw));
    sw.close();
    return sw.toString();
  }

  /**
   * Apply the XSLT stylesheet of associated framework (DITA, DocBook, custom framework etc.) to
   * specified XHTML fragment.
   * 
   * @param authorAccess        The {@link AuthorAccess} object of the current Author document.
   * @param xhtml               The XHTML fragment .
   * @param importerStylesheet  The XSLT stylesheet for applying to specified XHTML fragment.
   *
   * @return The result of the XSLT transformation.
   *
   * @throws TransformerException If transformation fails.
   * @throws MalformedURLException If a URL cannot be created.
   */
  private static String applyAssociatedXSL(
      AuthorAccess authorAccess, String xhtml, StreamSource importerStylesheet)
      throws TransformerException, MalformedURLException {
    ExtensionFunctionDefinition[] saxonExtensions = new ExtensionFunctionDefinition[6];
    saxonExtensions[0] = new URLUtilUncorrectFunctionCallDefinition();
    saxonExtensions[1] = new URLUtilCopyURLFunctionCallDefinition();
    saxonExtensions[2] = new UUIDRandomUUIDFunctionCallDefinition();
    saxonExtensions[3] = new UUIDHashCodeFunctionCallDefinition();
    saxonExtensions[4] = new URLNewFunctionCallDefinition();
    saxonExtensions[5] = new URLGetPathFunctionCallDefinition();
    Transformer transformer =
      authorAccess.getXMLUtilAccess().createSaxon9HEXSLTTransformerWithExtensions(
          importerStylesheet, saxonExtensions);
    
    URL editorUrl = authorAccess.getEditorAccess().getEditorLocation();
    String urlString = editorUrl.toString();
    int lastSlash = urlString.lastIndexOf("/");
    String parentPath = urlString.substring(0, lastSlash);
    URL pasteTargetURL = new URL(parentPath);
    transformer.setParameter("folderOfPasteTargetXml", URLUtil.correct(pasteTargetURL));
    if (logger.isDebugEnabled()) {
      logger.debug("folderOfPasteTargetXml: " + URLUtil.correct(pasteTargetURL));
    }
    StringWriter importerWriter = new StringWriter();
    transformer.transform(new StreamSource(new StringReader(xhtml)), new StreamResult(importerWriter));
    return importerWriter.toString();
  }
  
  /**
   * Read the initial XHTML content
   * @param xhtmlContentReader The XHTML content reader
   * @return The read content
   * @throws IOException
   */
  private static String readInitialXHTMLContent(Reader xhtmlContentReader) throws IOException {
    //Read the content in a buffer
    StringBuilder initialXHTMLToPasteBuilder = new StringBuilder();
    char[] buffer = new char[1024];
    int len = -1;
    while((len = xhtmlContentReader.read(buffer)) != -1){
      initialXHTMLToPasteBuilder.append(buffer, 0, len);
    }
    return initialXHTMLToPasteBuilder.toString();
  }

  /**
   * Create the InputSource for the XSLT stylesheet which will do the importing (transforming from the XHTML content to content valid in the current framework).
   * @return the stylesheet which will import from XHTML to this framework. By default imports only the string content.
   * 
   * @since 12.1
   */
  protected StreamSource createImporterStylesheetSource(AuthorAccess authorAccess) {
    String importerStylesheetFileName = getImporterStylesheetFileName(authorAccess);
    if (importerStylesheetFileName != null) {
      //Find it in the class loader resources
      URL resource = getClass().getClassLoader().getResource(importerStylesheetFileName);
      if (logger.isDebugEnabled()) {
        logger.debug("importer stylesheet name: " + importerStylesheetFileName);
      }
      if (logger.isDebugEnabled()) {
        logger.debug("importer stylesheet URL resource: " + resource);
      }
      if (resource == null) {
        //Probably running in the "classes"
        URL[] classPathResources = authorAccess.getClassPathResourcesAccess().getClassPathResources();
        if (logger.isDebugEnabled()) {
          logger.debug("classPathResources: " + Arrays.toString(classPathResources));
        }
        URLClassLoader ucl = new URLClassLoader(classPathResources);
        if (logger.isDebugEnabled()) {
          logger.debug("class loader: " + ucl.getClass().getName());
        }
        resource = ucl.findResource(importerStylesheetFileName);
        if (resource == null) {
          if (logger.isDebugEnabled()) {
            logger.debug("Could not find resource \"" + importerStylesheetFileName + "\" in class loader class path, but found it in a new class loader. Running from classes?");
          }
        } else {
          if (logger.isDebugEnabled()) {
            logger.debug("resource found by " + ucl 
                + " (instance of " + ucl.getClass().getName() + "): " 
                + ucl.getClass().getName());
          }
        }
      }
      if (resource != null) {
        //Use the stylesheet URL
        return new StreamSource(resource.toString());
      } else {
        String logMessage = "Could not find resource \"" + importerStylesheetFileName + "\" in class path.";
        if (logger.isDebugEnabled()) {
          logger.debug(logMessage);
        }
        logger.error(logMessage);
      }
    }
    //Return a default implementation which only copies the string content
    return new StreamSource(new StringReader(DEFAULT_STYLESHEET_CONTENT));
  }

  /**
   * Get the file name of the importer stylesheet. It will be resolved in the context of the current class loader.
   * @return the file name of the importer stylesheet. It will be resolved in the context of the current class loader.
   * 
   * @since 12.1
   */
  protected String getImporterStylesheetFileName(AuthorAccess authorAccess) {
    return null;
  }
  
  /**
   * Get the base URL for the node located at caret position.
   * Usually this is the URL of the opened editor but it can vary if nodes have xml:base defined on them.
   * @param authorAccess The author access
   * @return the base URL for the node located at caret position.
   */
  protected URL getBaseURLAtCaretPosition(AuthorAccess authorAccess) {
    URL base = authorAccess.getEditorAccess().getEditorLocation();
    try {
      AuthorNode nodeAtOffset = authorAccess.getDocumentController().getNodeAtOffset(authorAccess.getEditorAccess().getCaretOffset());
      if(nodeAtOffset != null) {
        base = nodeAtOffset.getXMLBaseURL();
      }
    } catch (BadLocationException e) {
      logger.error(e, e);
    }
    return base;
  }
  
  /**
   * Overwrite this method if you want to check the text data is preserved on paste after applying the conversion XSL stylesheet.
   * 
   * If the data is not preserved the content will be copied without any styling and a warning will appear in the console.
   * @return <code>false</code> by default.
   */
  protected boolean checkImportedXHTMLContentIsPreservedEntirely() {
    return false;
  }
  
  /**
   * Test data is preserver
   * @param contentProcessedByStylesheets
   * @param allWordsPresent
   * @return
   */
  static boolean testDataIsPreserved(String contentProcessedByStylesheets, String allWordsPresent) {
    boolean equal = true;
    if(! contentProcessedByStylesheets.equals(allWordsPresent)) {
      int li = 0;
      int ri = 0;
      int ll = contentProcessedByStylesheets.length();
      int rl = allWordsPresent.length();
      while(true) {
        if(li >= ll && ri >= rl) {
          //End of it
          break;
        }

        char lch = 0;
        boolean hasLeftToCompare = false;
        //Can still increment
        while(li < ll) {
          lch = contentProcessedByStylesheets.charAt(li);
          li ++;
          if(Character.isWhitespace(lch) 
              //NBSP
              || lch == 160) {
            continue;
          } else {
            //Break
            hasLeftToCompare = true;
            break;
          }
        }

        char rch = 0;
        boolean hasRightToCompare = false;
        //Can still increment
        while(ri < rl) {
          rch = allWordsPresent.charAt(ri);
          ri ++;
          if(Character.isWhitespace(rch) 
              //NBSP
              || rch == 160) {
            continue;
          } else {
            //Break
            hasRightToCompare = true;
            break;
          }
        }

        if(hasLeftToCompare && hasRightToCompare) {
          if(lch == rch) {
            //Perfect
          } else {
            equal = false;
            break;
          }
        } else if(! hasLeftToCompare && ! hasRightToCompare){
          //Good ending
          break;
        } else {
          //One has a character and the other has not.
          equal = false;
          break;
        }
      }
      if(! equal) {
        logger.warn("-----Problem preserving the XHTML data on paste, reverting to default.------");
        logger.warn("APPLIED XSLS DIFF NOT MATCHING:\n" + contentProcessedByStylesheets.substring(li));
        logger.warn("ONLY WORDS DIFF NOT MATCHING:\n" + allWordsPresent.substring(ri));
        logger.warn("Initial Processed pe XSLT content :\n" + contentProcessedByStylesheets);
        logger.warn("All Words content:\n" + allWordsPresent);
      }
    }
    return equal;
  }
}
