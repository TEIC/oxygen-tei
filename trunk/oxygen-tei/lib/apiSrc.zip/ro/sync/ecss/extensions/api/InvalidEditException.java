/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

/**
 * Exception thrown by {@link AuthorSchemaAwareEditingHandler} methods when an edit is considered invalid and must be rejected.
 */
public class InvalidEditException extends Exception {
  /**
   * Indicates if the error message must be presented or not to the user.
   */
  private boolean presentToUser;
  /**
   * Title message.
   */
  private final String title;
  /**
   * HTML styled message.
   */
  private String htmlMessage;
  /**
   * If <code>true</code> a link to the Schema aware preference page will be displayed with the 
   * error message.
   */
  private boolean showLinkToSchemaAwarePreferences;

  /**
   * Constructor.
   * @param title Title to be presented to the user. 
   * @param description Error message. 
   * @param presentToUser <code>true</code> if the error message must be presented to the user.
   * @param showLinkToSchemaAwarePreferences If <code>true</code> when the error message is presented to the user a link
   * to the Schema Aware preference page will be added.
   */
  public InvalidEditException(String title, String description, boolean presentToUser, boolean showLinkToSchemaAwarePreferences) {
    super(description);
    this.title = title;
    this.presentToUser = presentToUser;
    this.showLinkToSchemaAwarePreferences = showLinkToSchemaAwarePreferences;
  }
  
  /**
   * Constructor.
   * @param title Title to be presented to the user. 
   * @param description Error message. 
   * @param presentToUser <code>true</code> if the error message must be presented to the user.
   */
  public InvalidEditException(String title, String description, boolean presentToUser) {
    this(title, description, presentToUser, false);
  }
  
  /**
   * Constructor.
   * 
   * @param title Title to be presented to the user.
   * @param description Error message. 
   * @param  cause The exception cause. A <tt>null</tt> value is
   *         permitted, and indicates that the cause is nonexistent or
   *         unknown.
   * @param presentToUser <code>true</code> if the error message must be presented to the user.
   */
  public InvalidEditException(String title, String description, Throwable cause, boolean presentToUser) {
    super(description, cause);
    this.title = title;
    this.presentToUser = presentToUser;
  }
  
  /**
   * @return <code>true</code> if the error message should be presented to the user.
   */
  public boolean isPresentToUser() {
    return presentToUser;
  }
  
  /**
   * @return Returns the title.
   */
  public String getTitle() {
    return title;
  }
  
  /**
   * @param htmlMessage An error message that uses HTML elements for styling.
   */
  public void setHtmlMessage(String htmlMessage) {
    this.htmlMessage = htmlMessage;
  }
  
  /**
   * @return Returns the error message using HTML elements to style. <code>null</code> if a styled message is 
   * not available.
   */
  public String getHtmlMessage() {
    return htmlMessage;
  }
  
  /**
   * @param showLinkToSchemaAwarePreferences The showLinkToSchemaAwarePreferences to set.
   */
  public void setShowLinkToSchemaAwarePreferences(boolean showLinkToSchemaAwarePreferences) {
    this.showLinkToSchemaAwarePreferences = showLinkToSchemaAwarePreferences;
  }
  
  /**
   * @return Returns the showLinkToSchemaAwarePreferences.
   */
  public boolean isShowLinkToSchemaAwarePreferences() {
    return showLinkToSchemaAwarePreferences;
  }
  
  /**
   * Choose not to present the exception to the user.
   * @param presentToUser The presentToUser to set.
   */
  public void setPresentToUser(boolean presentToUser) {
    this.presentToUser = presentToUser;
  }
}
