/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.highlights;

import ro.sync.exml.view.graphics.Graphics;
import ro.sync.exml.view.graphics.Point;

/**
 * Information needed by the painter.
 */
public class HighlightPainterInfo {
  /**
   * Graphics
   */
  private final Graphics g;
  /**
   *  Current run of text/image height. Usually the highlight should expand 
   * as high as the containing box.
   */
  private final int currentBoxHeight;
  /**
   * Origin of box, relative to the upper corner of the editor. 
   */
  private final Point origin;
  /**
   * Relative X from where highlight should start
   */
  private final int relativeX;
  /**
   * Length of highlight, in pixels.
   */
  private final int length;
  /**
   * Start offset in content
   */
  private final int startOffset;
  /**
   * End offset in content
   */
  private final int endOffset;
  
  /**
   * Base line relative to top, relative to the box.
   */
  private final int baseLine;
  
  /**
   * The font ascent.
   */
  private final int fontAscent;
  
  /**
   * The font size.
   */
  private final int fontSize;
  
  /**
   * True if the highlight is done over a text view (by default)
   */
  private boolean isHighlightOverText = true;
  /**
   * The height of the parent line box. Can be -1 if no parent line box.
   */
  private final int parentLineBoxHeight;
  /**
   * The origin of the parent line box. Can be null if no parent line box.
   */
  private final Point parentLineBoxOrigin;
  /**
   * Renders the highlight.
   * 
   * @param g The graphics
   * @param currentBoxHeight The current box height.
   * @param origin Origin (upper left corner of the box in absolute coordinates)
   * @param relativeX The x relative to the origin where the highlight must start.
   * @param length The length of the highlight, in pixels.
   * @param startOffset Start offset of highlight
   * @param endOffset End offset of highlight
   * @param baseLine The base line relative to the box start
   * @param fontAscent  The font ascent
   * @param fontSize The font size
   * @param parentLineBoxHight The height of the parent line box. Can be -1.
   * @param parentLineBoxOrigin The origin of the parent line box. Can be null. 
   */
  public HighlightPainterInfo(Graphics g, int currentBoxHeight, Point origin, int relativeX, int length, 
      int startOffset, int endOffset, int baseLine, int fontAscent, int fontSize, int parentLineBoxHight
      , Point parentLineBoxOrigin) {
    this.g = g;
    this.currentBoxHeight = currentBoxHeight;
    this.origin = origin;
    this.relativeX = relativeX;
    this.length = length;
    this.endOffset = endOffset;
    this.startOffset = startOffset;
    this.baseLine = baseLine;
    this.fontAscent = fontAscent;
    this.fontSize = fontSize;
    this.parentLineBoxHeight = parentLineBoxHight;
    this.parentLineBoxOrigin = parentLineBoxOrigin;
  }
  
  /**
   * It is set by the author layout, so that the painter knows the painted box is a text box.
   * @param isHighlightOverText The isHighlightOverText to set.
   */
  public void setHighlightOverText(boolean isHighlightOverText) {
    this.isHighlightOverText = isHighlightOverText;
  }
  
  /**
   * Returns the graphics used for paint.
   * 
   * @return Returns the graphics used for paint.
   */
  public Graphics getGraphics() {
    return g;
  }

  /**
   * Current run of text/image height. Usually the highlight should expand 
   * as high as the containing box.
   * 
   * @return Current run of text/image height. Usually the highlight should expand 
   * as high as the containing box.
   */
  public int getCurrentBoxHeight() {
    return currentBoxHeight;
  }

  /**
   * Returns the origin of box, relative to the upper corner of the editor. 
   * 
   * @return Returns the origin of box, relative to the upper corner of the editor. 
   */
  public Point getOrigin() {
    return origin;
  }

  /**
   * Returns the relative X from where highlight should start.
   * 
   * @return Returns the relative X from where highlight should start.
   */
  public int getRelativeX() {
    return relativeX;
  }

  /**
   * Returns the length of highlight, in pixels.
   * 
   * @return Returns the length of highlight, in pixels.
   */
  public int getLength() {
    return length;
  }

  /**
   * Returns the start offset in content.
   * 
   * @return Returns the start offset in content.
   */
  public int getStartOffset() {
    return startOffset;
  }

  /**
   * Returns the end offset in content.
   * 
   * @return Returns the end offset in content.
   */
  public int getEndOffset() {
    return endOffset;
  }

  /**
   * Returns the base line relative to top, relative to the box.
   * 
   * @return Returns the base line relative to top, relative to the box.
   */
  public int getBaseLine() {
    return baseLine;
  }

  /**
   * Returns the font ascent. 
   * 
   * @return Returns the font ascent. 
   */
  public int getFontAscent() {
    return fontAscent;
  }

  /**
   * Returns the font size.
   * 
   * @return Returns the font size.
   */
  public int getFontSize() {
    return fontSize;
  }

  /**
   * Returns true if the highlight is done over a text view.
   * 
   * @return Returns true if the highlight is done over a text view.
   */
  public boolean isHighlightOverText() {
    return isHighlightOverText;
  }
  
  /**
   * @return Returns the height of parent line box. Can be -1.
   */
  public int getParentLineBoxHight() {
    return parentLineBoxHeight;
  }
  
  /**
   * @return Returns the origin(absolute) of the parent line box. Can be null.
   */
  public Point getParentLineBoxOrigin() {
    return parentLineBoxOrigin;
  }
}
