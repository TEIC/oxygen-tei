/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.editor.xmleditor.pageauthor;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;

import ro.sync.ecss.extensions.api.AWTExtension;
import ro.sync.ecss.extensions.api.AuthorAccess;

/**
 * Author Drag and Drop listener interface for the AWT implementation.
 * The <code>AuthorDnDListener</code> interface 
 * is the callback interface used by the author editor page to provide 
 * notification of DnD operations that involve it.
 * <p>
 * Create a listener object by implementing the interface and then when 
 * the drag enters, moves over, or exits
 * the author editor page, when 
 * the drop action changes, and when the drop occurs, the relevant method in 
 * the listener object is invoked, and the <code>DropTargetEvent</code> is 
 * passed to it.
 */
public interface AuthorDnDListener extends AWTExtension {

  /**
   * Called when a drag operation is ongoing, while the mouse pointer is still
   * over the author editor page where this listener is registered.
   * 
   * @param event The {@link DropTargetDropEvent} event.
   * @return <code>true</code> if the listener handled the event.
   */
  boolean authorDragOver(DropTargetDragEvent event);

  /**
   * Called when the drag operation has terminated with a drop on
   * the author editor page where this listener is registered.  
   * <p>
   * This method is responsible for undertaking
   * the transfer of the data associated with the
   * gesture. The <code>DropTargetDropEvent</code> 
   * provides a means to obtain a <code>Transferable</code>
   * object that represents the data object(s) to 
   * be transfered.<P>
   * 
   * @param transferable The {@link Transferable} object.
   * @param event The {@link DropTargetDragEvent} event.
   * @return <code>true</code> if the listener handled the event.
   */
  boolean authorDrop(Transferable transferable, DropTargetDropEvent event);
  
  /**
   * Check if the data flavor can be handled by the listener.
   * 
   * @param flavor The {@link DataFlavor} flavor.
   * @return <code>true</code> if the flavor is supported.
   */
  boolean authorSupportsFlavor(DataFlavor flavor);

  /**
   * Called while a drag operation is ongoing, when the mouse pointer has
   * exited the author editor page where this listener is registered.
   *  
   * @param event The {@link DropTargetEvent} event.
   * @return <code>true</code> if the listener consumed the drag exit event.
   */
  boolean authorDragExit(DropTargetEvent event);
  
  /**
   * Called while a drag operation is ongoing, when the mouse pointer enters
   * the author editor page where this listener is registered.
   * 
   * @param event The {@link DropTargetDragEvent} event.
   * @return <code>true</code> if the listener consumed the drag enter event.
   */
  boolean authorDragEnter(DropTargetDragEvent event);

  /**
   * Initialize the DnD listener.
   * 
   * @param authorAccess The {@link AuthorAccess} providing access to 
   * specific components corresponding to editor, document, workspace, 
   * tables, change tracking and utility informations and actions.
   */
  void init(AuthorAccess authorAccess); 
}