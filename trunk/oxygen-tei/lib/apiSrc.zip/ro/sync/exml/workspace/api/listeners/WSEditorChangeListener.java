/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.listeners;

import java.net.URL;

/**
 * Notified when an editor is added, removed or the editor page is changed
 * 
 * @since 11.2 
 */
public class WSEditorChangeListener {
  
  /**
   * An editor will be opened. You can reject the close of the editor by returning <code>false</code>.
   * If the open is not rejected then the {@link WSEditorChangeListener#editorAboutToBeOpened(URL)} and then {@link WSEditorChangeListener#editorOpened(URL)} methods will be called.
   * 
   * @param editorLocation The editor's location.
   * @return <code>true</code> to proceed with the close, <code>false</code> to reject the close of the editor.
   *  
   * In the standalone Oxygen version the listener is called before showing the "Save As" dialog to the user.
   * In the Eclipse implementation the listener  is called after showing the "Save As" dialog to the user and the operation can not be reject..
   * 
   * @since 12.2
   */
  public boolean editorAboutToBeOpenedVeto(URL editorLocation) {
    return true;
  }
  
  /**
   * An editor will be opened. If the open does not fail, then the {@link WSEditorChangeListener#editorOpened(URL)} method will be called.
   * @param editorLocation The editor's location
   * 
   * @since 12.1
   */
  public void editorAboutToBeOpened(URL editorLocation) {
    //
  }
  /**
   * An editor was opened.
   * 
   * @param editorLocation The editor's location
   */
  public void editorOpened(URL editorLocation) {
    //
  }
  /**
   * An editor was closed.
   * 
   * @param editorLocation The editor's location
   */
  public void editorClosed(URL editorLocation) {
    //
  }
  /**
   * An editor was selected in the tabbed pane.
   * 
   * @param editorLocation The editor's location
   */
  public void editorSelected(URL editorLocation) {
    //
  }
  /**
   * The current page for an editor has changed. This means the user switched for example from the <b>Text</b> to the <b>Author</b> page.
   * An XML Editor usually has 3 pages: <b>Text</b>, <b>Grid</b> and <b>Author</b>. 
   * 
   * @param editorLocation The editor's location
   */
  public void editorPageChanged(URL editorLocation) {
    //
  }
  
  /**
   * An editor was activated. It is the selected editor but also the editor in which the focus is present.
   * @param editorLocation The editor's location
   * 
   * @since 12.2
   */
  public void editorActivated(URL editorLocation) {
    //
  }
  
  /**
   * An editor was de-activated. Focus is no longer present in it. 
   * Maybe the editor was already closed.
   * @param editorLocation The editor's location
   * 
   * @since 12.2
   */
  public void editorDeactivated(URL editorLocation) {
    //
  }
  
  /**
   * An editor will be closed. You can reject the close of the editor by returning <code>false</code>.
   * @param editorLocation The editor's location
   * @return <code>true</code> to proceed with the close, <code>false</code> to reject the close of the editor.
   * 
   * @since 12.2
   */
  public boolean editorAboutToBeClosed(URL editorLocation) {
    return true;
  }
  
  
  /**
   * An editor was relocated to a new location. Probably <b>Save As</b> was called on the opened editor.
   *
   * @param previousEditorLocation The previous editor's location
   * @param newEditorLocation The current editor's location
   * 
   * @since 12.2
   */
  public void editorRelocated(URL previousEditorLocation, URL newEditorLocation) {
    //
  }
}
