/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2011 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone;

import ro.sync.exml.workspace.api.util.RelativeReferenceResolver;

/**
 * Contains methods for customizing the Input URL Choosers and for computing relative paths from URLs in an implementation specific manner.
 * 
 * @since 13
 * <br>
 * <br>
 * *********************************
 * <br>
 * EXPERIMENTAL - Subject to change
 * <br>
 * ********************************
 * </br>
 * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
 * comments about it, please let us know.</p> 
 */
public interface ReferencesCustomizer {
  /**
   * Adds a customizer which can modify the list of "Browse" actions. These actions are available in Oxygen, in any control or dialog that contains an URL input box. 
   * <br/>
   * <b>IMPORTANT</b> This customizer must be set early, when the plugin extension's <b>applicationStarted</b> method gets called or after the AuthorComponentFactory was initialized (if running the Author component).
   * <br/>
   * <i>Example:</i> If a CMS developer wants the user to choose the URL from their custom CMS chooser then it will add a new action (possibly removing the others).
   * When the new action gets called the custom code shows the custom chooser and at the end it can call the 
   * <b>ro.sync.exml.workspace.api.standalone.InputURLChooser</b> interface to set the new URL in the combo box. 
   * 
   * @param inputURLChooserCustomizer The input URL chooser customizer.
   * 
   * @since 12.1
   */
  public void addInputURLChooserCustomizer(InputURLChooserCustomizer inputURLChooserCustomizer);
  
  /**
   * Add a relative reference resolver for a certain URL protocol.
   * This method can be used by a CMS implementor to take control over the way Oxygen is computing relative references for a certain URL protocol.
   * For example when inserting in a DITA Topic a reference to an image Oxygen will try to make the reference relative to the current XML document.
   * If the DITA Topic is opened using your custom URL protocol you can take control over they way in which the relative path is computed.
   * 
   * @param protocol The URL protocol for which you want to take control over the relativization.
   * @param resolver The custom resolver.
   * 
   * @since 12.2
   */
  public void addRelativeReferencesResolver(String protocol, RelativeReferenceResolver resolver);
}
