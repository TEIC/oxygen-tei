/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.options;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import ro.sync.ecss.extensions.api.OptionChangedEvent;
import ro.sync.ecss.extensions.api.OptionListener;
import ro.sync.exml.options.Options;
import ro.sync.options.AbstractPropertyListener;
import ro.sync.options.PropertyEvent;

/**
 * Options storage implementation.
 */
public class WSOptionsStorageImpl implements WSOptionsStorage {
  
  /** * Logger for logging. */
  private static Logger logger = Logger.getLogger(WSOptionsStorageImpl.class.getName());
  
  /**
   * Option listener wrapper used to notify the public option listeners.
   */
  private static class OptionListenerWrapper extends AbstractPropertyListener {
    /**
     * The wrapped {@link OptionListener}.
     */
    private WSOptionListener listener;
    /**
     * The {@link PropertyEvent} that triggered the last update.
     * Note that after the {@link OptionChangedEvent} has been fired this is set to <code>null</code>
     * to avoid misfire.
     */
    private PropertyEvent event;

    /**
     * Constructor.
     * 
     * @param listener The wrapped listener.
     * @param optionsDocTypePrefix The document type prefix used to build the options keys. 
     */
    public OptionListenerWrapper(WSOptionListener listener, String optionsDocTypePrefix) {
      super(optionsDocTypePrefix + listener.getKey());
      this.listener = listener;
    }
    
    /**
     * @see ro.sync.options.AbstractPropertyListener#update(ro.sync.options.PropertyEvent)
     */
    @Override
    public void update(PropertyEvent event) {
      this.event = event;
      super.update(event);
      this.event = null;
    }
    
    /**
     * @see ro.sync.options.AbstractPropertyListener#update()
     */
    @Override
    public void update() {
      if (this.event != null) {
        listener.optionValueChanged(
            new WSOptionChangedEvent(
                listener.getKey(), 
                (String) event.getOldValue(), 
                (String) event.getNewValue()));
      }
    }
    
    /**
     * @return Returns the listener.
     */
    public WSOptionListener getListener() {
      return listener;
    }
  }
  
  /**
   * The list with the wrappers over the option listeners.
   */
  private List<OptionListenerWrapper> listeners = new ArrayList<OptionListenerWrapper>() {
    @Override
    public boolean remove(Object o) {
      if (o instanceof WSOptionListener) {
        for (Iterator iterator = this.iterator(); iterator.hasNext();) {
          OptionListenerWrapper wrapper = (OptionListenerWrapper) iterator.next();
          if (wrapper.getListener() == o) {
            if (logger.isDebugEnabled()) {
              logger.debug("Remove prop listener |" + wrapper.getListener().getKey() + "|");
            }
            Options.getInstance().removePropertyListener(wrapper);
            return super.remove(o);
          }
        }
      }
      return false;
    }
    
    @Override
    public void clear() {
      for (Iterator iterator = this.iterator(); iterator.hasNext();) {
        OptionListenerWrapper wrapper = (OptionListenerWrapper) iterator.next();
        if (logger.isDebugEnabled()) {
          logger.debug("Remove prop listener |" + wrapper.getListener().getKey() + "|");
        }
        Options.getInstance().removePropertyListener(wrapper);
      }
      super.clear();
    }
  };
  
  /**
   * The prefix the current document type descriptor uses for its related options.
   */
  private String optionsDoctypePrefix;
  
  /**
   * @see ro.sync.ecss.extensions.api.OptionsStorage#addOptionListener(ro.sync.ecss.extensions.api.OptionListener)
   */
  public void addOptionListener(WSOptionListener listener) {
    if (optionsDoctypePrefix != null) {
      OptionListenerWrapper wrapper = new OptionListenerWrapper(listener, optionsDoctypePrefix);
      listeners.add(wrapper);
      Options.getInstance().addPropertyListener(wrapper);
      if (logger.isDebugEnabled()) {
        logger.debug("Add option listener for |" + wrapper.getListener().getKey() + "|");
      }
    }
  }

  /**
   * @see ro.sync.ecss.extensions.api.OptionsStorage#getOption(java.lang.String, java.lang.String)
   */
  public String getOption(String key, String defaultValue) {
    String toReturn = defaultValue;
    if (optionsDoctypePrefix != null) {
      toReturn = Options.getInstance().getStringProperty(optionsDoctypePrefix + key);
      if (toReturn == null) {
        toReturn = defaultValue;
      }
    }
    return toReturn;
  }

  /**
   * @see ro.sync.ecss.extensions.api.OptionsStorage#removeOptionListener(ro.sync.ecss.extensions.api.OptionListener)
   */
  public void removeOptionListener(WSOptionListener listener) {
    if (logger.isDebugEnabled()) {
      logger.debug("Remove option listener for |" + listener.getKey() + "|");
    }
    listeners.remove(listener);
  }

  /**
   * @see ro.sync.ecss.extensions.api.OptionsStorage#setOption(java.lang.String, java.lang.String)
   */
  public void setOption(String key, String value) {
    if (optionsDoctypePrefix != null) {
      if (value != null) {
        Options.getInstance().setStringProperty(optionsDoctypePrefix + key,  value);
      } else {
        Options.getInstance().remove(optionsDoctypePrefix + key);
      }
    }
  }
  
  /**
   * Removes all options listeners.
   */
  public void removeAllListeners() {
    if (logger.isDebugEnabled()) {
      logger.debug("Clear all");
    }
    listeners.clear();
  }
  
  /**
   * @param optionsDoctypePrefix The document type prefix used to build the options keys.
   * This should not be <code>null</code>.
   */
  public void setOptionsDoctypePrefix(String optionsDoctypePrefix) {
    if (optionsDoctypePrefix != null) {
      this.optionsDoctypePrefix = optionsDoctypePrefix + ".";
    } else {
      this.optionsDoctypePrefix = null;
    }
  }
}