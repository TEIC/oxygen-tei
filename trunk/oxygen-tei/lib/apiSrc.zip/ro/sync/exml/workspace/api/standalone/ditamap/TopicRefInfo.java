/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone.ditamap;

import java.util.HashMap;
import java.util.Map;

/**
 * A map holding information about the topic reference in the DITA Map.
 * This is filled on the Oxygen side.
 * 
 * @since 12.2
 */
public class TopicRefInfo {
  
  /**
   * The absolute URL of the topic reference computed by Oxygen from the "href" value. It does not include the id location.
   */
  public static final String ABSOLUTE_URL = "absoluteURL";
  
  /**
   * The ID location (if any) inside the targeted URL.
   */
  public static final String ID_PATH = "idPath";
  
  /**
   * The value of the "href" attribute of the <topicref> element.
   */
  public static final String HREF_VALUE = "href";
  
  /**
   * A map of accepted properties.
   */
  private final Map<String, Object> properties = new HashMap<String, Object>();
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #ABSOLUTE_URL}</li>
   *  <li>{@link #ID_PATH}</li>
   *  <li>{@link #HREF_VALUE}</li>
   * </ul>
   * 
   * For example if a DITA Map with the URL "cms://test/file.ditamap" references a topic using the {@link #HREF_VALUE} <b>task.dita#task</b>
   * then the {@link #ABSOLUTE_URL} of the topic reference will be <b>cms://test/task.dita</b> and the {@link #ID_PATH} will be <b>task</b>
   * @return The property value or <code>null</code> if not available.
   */
  public Object getProperty(String propertyName) {
    return properties.get(propertyName);
  }
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #ABSOLUTE_URL}</li>
   *  <li>{@link #ID_PATH}</li>
   *  <li>{@link #HREF_VALUE}</li>
   * </ul>
   * @param propertyValue The value of the property.
   * @throws IllegalArgumentException If the property name is not one of the constants in this class.
   */
  public void setProperty(String propertyName, Object propertyValue) {
    if (propertyName == null || (!propertyName.equals(ABSOLUTE_URL) 
        && !propertyName.equals(HREF_VALUE) && !propertyName.equals(ID_PATH))) {
      throw  new IllegalArgumentException("Invalid property name: " + propertyName);
    }
    properties.put(propertyName, propertyValue);
  }
}
