/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.standalone.ditamap;

import java.util.HashMap;
import java.util.Map;

/**
 * A map holding information about the target of a topic reference.
 * This is filled on the API side.
 * 
 * @since 12.2
 */
public class TopicRefTargetInfo {
  /**
   * The title of the target
   */
  public final static String TITLE = "title";
  /**
   * The class value of the target.
   */
  public final static String CLASS_VALUE = "class";
  /**
   * The element name.
   */
  public final static String ELEMENT_NAME = "element";
  /**
   * An error message if error (file not found or parse) occured reading the topic
   */
  public final static String PARSE_ERROR = "parseError";
  /**
   * If set to the string "true" then the Plugin API handled the reference, 
   * if not the default approach should be performed (Oxygen requests the entire content of the reference and parses the title and other properties).  
   */
  public final static String RESOLVED = "resolved";
  
  /**
   * A map of accepted properties.
   */
  private final Map<String, Object> properties = new HashMap<String, Object>();
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #RESOLVED}</li>
   *  <li>{@link #TITLE}</li>
   *  <li>{@link #CLASS_VALUE}</li>
   *  <li>{@link #ELEMENT_NAME}</li>
   *  <li>{@link #PARSE_ERROR}</li>
   * </ul>
   * @return The property value or <code>null</code> if not available.
   */
  public Object getProperty(String propertyName) {
    return properties.get(propertyName);
  }
  
  /**
   * Get the value of a recognized property.
   * 
   * @param propertyName The property name. One of the following constants:
   * <ul>
   *  <li>{@link #RESOLVED}</li>
   *  <li>{@link #TITLE}</li>
   *  <li>{@link #CLASS_VALUE}</li>
   *  <li>{@link #ELEMENT_NAME}</li>
   *  <li>{@link #PARSE_ERROR}</li>
   * </ul>
   * @param propertyValue The value of the property.
   * @throws IllegalArgumentException If the property name is not one of the constants in this class.
   */
  public void setProperty(String propertyName, Object propertyValue) throws IllegalArgumentException {
    if (propertyName == null || (!propertyName.equals(ELEMENT_NAME) && !propertyName.equals(CLASS_VALUE) && !propertyName.equals(TITLE)
        && !propertyName.equals(PARSE_ERROR) && !propertyName.equals(RESOLVED))) {
      throw  new IllegalArgumentException("Invalid property name: " + propertyName);
    }
    properties.put(propertyName, propertyValue);
  }
}
