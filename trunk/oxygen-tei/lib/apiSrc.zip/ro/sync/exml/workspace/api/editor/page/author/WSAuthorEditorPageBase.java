/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.exml.workspace.api.editor.page.author;

import ro.sync.ecss.css.Styles;
import ro.sync.ecss.extensions.api.AuthorCaretListener;
import ro.sync.ecss.extensions.api.AuthorMouseListener;
import ro.sync.ecss.extensions.api.AuthorSchemaAwareEditingHandler;
import ro.sync.ecss.extensions.api.AuthorViewToModelInfo;
import ro.sync.ecss.extensions.api.StylesFilter;
import ro.sync.ecss.extensions.api.attributes.AuthorAttributesDisplayFilter;
import ro.sync.ecss.extensions.api.highlights.AuthorHighlighter;
import ro.sync.ecss.extensions.api.highlights.AuthorPersistentHighlighter;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.ecss.extensions.api.structure.AuthorPopupMenuCustomizer;
import ro.sync.exml.workspace.api.editor.page.WSTextBasedEditorPage;
import ro.sync.exml.workspace.api.editor.page.author.actions.AuthorActionsProvider;

/**
 * Provides access to methods related to the Author editor actions and information.
 * 
 * @since 11.2 
 */
public interface WSAuthorEditorPageBase extends WSTextBasedEditorPage {
  
  /**
   * Get the position in the document corresponding to the point in the author viewport component.
   * 
   * @param x The "x" coordinate relative to the viewport origin.
   * @param y The "y" coordinate relative to the viewport origin.
   * @return  The {@link AuthorViewToModelInfo} containing the offset and the node
   * at offset corresponding to the given point. The method does not return <code>null</code>, 
   * instead an undefined view to model info object is returned if a valid one could not be determined.
   */
  AuthorViewToModelInfo viewToModel(int x, int y);
  
  /**
   * Set the pop-up menu customizer which can be used to customize the pop-up menu (add/remove actions) before showing it in the Author page.
   * @param popUpCustomizer the pop-up menu customizer.
   */
  void setPopUpMenuCustomizer(AuthorPopupMenuCustomizer popUpCustomizer);
  
  /**
   * Adds a mouse listener to the current author page.
   * 
   * @param mouseListener The {@link AuthorMouseListener} to be added.
   */
  void addAuthorMouseListener(AuthorMouseListener mouseListener);
  
  /**
   * Removes the specified mouse listener from the current author page.
   * 
   * @param mouseListener The {@link AuthorMouseListener} to be removed. 
   */
  void removeAuthorMouseListener(AuthorMouseListener mouseListener);
  
  /**
   * Adds a caret listener to the Author page.
   * 
   * @param caretListener The {@link AuthorCaretListener} to be added.
   */
  void addAuthorCaretListener(AuthorCaretListener caretListener);
 
  /**
   * Removes the specified caret listener from the Author page.
   * 
   * @param caretListener The {@link AuthorCaretListener} to be removed.
   */
  void removeAuthorCaretListener(AuthorCaretListener caretListener);
  
  /**
   * Refresh the rendering layout and CSS styles for this node and all its contents.
   * 
   * @param authorNode The node for which the layout and styles will be recomputed.
   */
  void refresh(AuthorNode authorNode);
  
  /**
   * Reload the CSS files and perform a refresh on the whole document to recompute
   * the layout and the styles for all the nodes based on the new CSS files
   * content.
   */
  void refresh();
  
  /**
   * Get the highlighter which can be used to add/remove/manage the custom user highlights
   * @return The highlighter which can be used to add/remove/manage the custom user highlights.
   */
  AuthorHighlighter getHighlighter();
  
  /**
   * Get the persistent highlighter which can be used to add/remove/manage the 
   * custom persistent user highlights.
   * <br/>
   * Persistent highlights get serialized in the XML as processing instructions with the form:
   * <br/>
   * <code>&lt;?oxy_custom_start prop1="val1"....?> xml content &lt;?oxy_custom_end?></code>
   * 
   * @return The persistent highlighter which can be used to add/remove/manage the custom user highlights.
   * 
   * @since 12
   */
  AuthorPersistentHighlighter getPersistentHighlighter();
  
  /**
   * Usually returns the same value as {@link #getSelectionStart()}. 
   * <br/>
   * If the selection start is immediately to the right of a start tag and the corresponding end tag 
   * is contained in the selection, then the balanced selection start will be obtained by extending
   * the selection start to contain the start tag.
   * 
   * @return The balanced selection start offset, 0 based.
   * 
   * @since 12
   */
  int getBalancedSelectionStart();
  
  /**
   * Usually returns the same value as {@link #getSelectionEnd()}. 
   * <br/>
   * If the selection end is immediately to the left of a end tag and the corresponding start tag 
   * is contained in the selection, then the balanced selection end will be obtained by extending
   * the selection end to contain the end tag.
   * 
   * @return The balanced selection end offset, 0 based.
   * 
   * @since 12
   */
  int getBalancedSelectionEnd();
  
  /**
   * Get the default schema aware editing handler.
   * This can be used from a custom AuthorSchemaAwareEditingHandler implementation from an ExtensionsBundle to delegate various operations to.
   * @return the default schema aware editing handler.
   * 
   * @since 12.1
   */
  AuthorSchemaAwareEditingHandler getDefaultAuthorSchemaAwareEditingHandler();
  
  /**
   * Provides access to actions already defined in the Author page like: Undo, Redo, Display Full Tags, Edit Attributes, etc.
   * @return access to actions already defined in the Author page.
   * 
   * @since 12.1
   */
  AuthorActionsProvider getActionsProvider();
  
  /**
   * Get the internal component on which the Author page is rendered.
   * 
   * Use of this method is discouraged but it may be useful in some cases like:
   * 
   * This can be helpful when you want to set a busy cursor on the component for example or when you want to get access to the scroll bars.
   * You can also request focus in the component by casting it to its native equivalent.
   * 
   * @return for the stand alone version, a javax.swing.JPanel and for the eclipse implementation a org.eclipse.swt.widgets.Canvas.
   * 
   * @since 12.2
   */
  Object getAuthorComponent();
  
  /**
   * Get the CSS styles which are used to render a particular Author node.
   * This method <b>MUST</b> only be used to query styles. If you want to modify styles please use the {@link StylesFilter}.
   * @param node The node for which we want to obtain the styles.
   * @return the styles associated with the node.
   * 
   * @since 12.2
   */
  Styles getStyles(AuthorNode node); 
  
  /**
   * Adds a filter for displaying attributes to the current author page.
   * 
   * @param attributesDisplayFilter The {@link AuthorAttributesDisplayFilter} to be added.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  void addAuthorAttributesDisplayFilter(AuthorAttributesDisplayFilter attributesDisplayFilter);
  
  /**
   * Remove a filter for displaying attributes to the current author page.
   * 
   * @param attributesDisplayFilter The {@link AuthorAttributesDisplayFilter} to be added.
   * 
   * @since 13
   * <br>
   * <br>
   * *********************************
   * <br>
   * EXPERIMENTAL - Subject to change
   * <br>
   * ********************************
   * </br>
   * <p>Please note that this API is not marked as final and it can change in one of the next versions of the application. If you have suggestions, 
   * comments about it, please let us know.</p>   
   */
  void removeAuthorAttributesDisplayFilter(AuthorAttributesDisplayFilter attributesDisplayFilter);
}